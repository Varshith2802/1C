# SWE-2C — Real-Time Fraud Detection Microservices Architecture

> **STRICTLY PRIVATE AND CONFIDENTIAL — NOT FOR CIRCULATION**
>
> All intellectual property in this repository belongs to **Zetheta Algorithms Private
> Limited**. Produced against Zetheta project brief 463549C. No part may be copied,
> published or disclosed to any third party without Zetheta's prior written consent.

Architectural design for decomposing **ShieldPay Financial Services**' 1.2 MLOC Java
monolith into a real-time fraud detection microservices platform. 2.4 M transactions/day
across India, Southeast Asia and the Middle East, following a 340% surge in fraud attempts
that took quarterly losses from ₹12 crore to ₹53 crore.

This is an **architecture and design** deliverable. Nothing here is a running system; every
configuration, schema and manifest is a specification validated for syntax, not a deployed
artefact. Where a claim is an estimate rather than a measurement, it says so.

## Start here

| If you are the… | Read |
|---|---|
| CTO | [Master Architecture Document](docs/00_MASTER_ARCHITECTURE.md) → [Service Decomposition](docs/04_SERVICE_DECOMPOSITION.md) → [C4 diagrams](diagrams/) |
| CRO | [Rule Engine](docs/09_RULE_ENGINE_DESIGN.md) → [ML Architecture](docs/10_ML_ARCHITECTURE.md) → [Graph Analysis](docs/11_GRAPH_ANALYSIS_DESIGN.md) |
| VP Engineering | [SLA Specification](docs/05_SLA_SPECIFICATION.md) → [CI/CD & DR](docs/15_CICD_AND_DR.md) → [samples/](samples/) |
| Head of Compliance | [Security & Compliance](docs/12_SECURITY_AND_COMPLIANCE.md) → [Observability](docs/14_OBSERVABILITY.md) |
| CFO | [Master Architecture §9 Cost](docs/00_MASTER_ARCHITECTURE.md#9-cost-model-and-roi) |
| Assessor | [ERROR_DETECTION.md](docs/ERROR_DETECTION.md) · [SELF_ASSESSMENT.md](docs/SELF_ASSESSMENT.md) · [AI_USAGE.md](docs/AI_USAGE.md) |

## Repository layout

```
docs/          16 design documents + error detection, AI usage, self-assessment
diagrams/      C4 L1/L2/L3, event storming, sagas, rule lifecycle, deployment topology
api-specs/     OpenAPI 3.0 spec, 6 Protobuf service definitions, gateway routing table
configs/       20 rule definitions + JSON Schema, Kafka topics, Istio policies,
               Prometheus alerts, Grafana dashboards
samples/       Dockerfiles and Kubernetes manifests for 2 services, 1 Helm chart
presentation/  15-minute Board presentation
daily-commits/ Day 1–15 work logs
```

## The five embedded errors

Day 15 requires locating five errors planted in the brief. They are identified in
**[docs/ERROR_DETECTION.md](docs/ERROR_DETECTION.md)**, with six further inconsistencies
that are not flagged in the brief but are real:

| | Location | Error |
|---|---|---|
| E1 | Part D, Day 5 heading | "API Contract Design (**OPENAI** and Protobuf)" — the standard is OpenAPI 3.0; OpenAI is an unrelated company |
| E2 | Part A §A2.3 heading | "Anomaly Detection And Machine **Laarnign**" |
| E3 | §A2.5 vs §A3.3 vs §A1.4 | Decision SLA (<100 ms) is tighter than the pipeline p99 it depends on (200 ms), and carries no percentile |
| E4 | §A1.5 vs §A1.2 | The Fraud Investigation Saga is orchestrated across a "Card Management Service" that exists in no bounded context |
| E5 | §E3 vs Part D submission vs Part C | Three mutually inconsistent project/repository naming schemes (SWE-2C / 463549C / 201169C) |

## Headline design positions

Three places where this design departs from the brief, argued in full in the Master
Architecture Document:

1. **Graph analysis is off the synchronous critical path.** The brief offers a synchronous/
   asynchronous choice. Synchronous is arithmetically impossible inside the stated budget —
   see [§3.4](docs/00_MASTER_ARCHITECTURE.md#34-the-latency-budget-does-not-close).
2. **Nine services, not twelve.** Each additional service costs a network hop the latency
   budget cannot spare and a failure mode the on-call rota must carry.
3. **The ML model is a risk, not only a control.** A model trained on labels that arrive
   30–90 days late cannot detect a campaign that runs for two weeks. Rules and graph carry
   novel-attack detection; ML carries volume.

© Zetheta Algorithms Private Limited. Proprietary and confidential.
