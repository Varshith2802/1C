# Day 01 — Domain Immersion

**Commit tag:** `Day01_Domain_Immersion`

## What I completed
Read Part A sections A1-A2. Built a 62-term glossary. Analysed the legacy monolith and mapped 11 modules to business capabilities. Ran an event storming pass producing 56 domain events.

## Key decision
Batch scoring is the root cause, not hard-coded rules. The 15-minute window is exploitable by design and no other fix matters until it closes.

## Blockers / risks
Brief gives 2.4M txn/day but no peak figure. Derived ~170 TPS sustained peak / 500 TPS burst from Indian evening and festival traffic patterns; flagged as an assumption.
