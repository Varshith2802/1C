# Day 10 — Security Design

**Commit tag:** `Day10_Security_Design`

## What I completed
Wrote 10 Istio resources, the service communication matrix, encryption strategy and full PCI DSS mapping.

## Key decision
PCI Req 3 satisfied by schema absence. No PAN field exists past tokenisation, so a logging accident cannot leak one.

## Blockers / risks
card_number_hash is a join key across four stores - naive key rotation invalidates every stored hash at once. Added versioned derivation so annual rotation is actually executable.
