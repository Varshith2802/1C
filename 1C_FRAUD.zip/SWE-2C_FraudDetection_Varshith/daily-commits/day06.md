# Day 06 — Event-Driven Architecture

**Commit tag:** `Day06_Event-Driven_Architecture`

## What I completed
Documented 56 events with aggregates and policies. Specified 3 sagas and 5 CQRS read models.

## Key decision
Choreography for the transaction path (linear, nothing to compensate), orchestration for investigation (branching, human-in-loop, real compensations).

## Blockers / risks
Modelled card freeze as the external core banking system rather than inventing the service the brief names. Confirms E4.
