# Day 13 — Observability

**Commit tag:** `Day13_Observability`

## What I completed
Wrote the structured logging standard, OpenTelemetry tracing config and SLO measurement methodology.

## Key decision
Trace context propagates across Kafka headers, not just gRPC. Without it the entire async half of the platform is invisible to tracing.

## Blockers / risks
PII masking enforced at the serialiser with a CI test that logs a synthetic PAN and fails the build if it appears. A policy asking developers not to log PANs fails eventually.
