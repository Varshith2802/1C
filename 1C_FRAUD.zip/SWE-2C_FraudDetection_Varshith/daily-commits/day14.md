# Day 14 — CI/CD and DR

**Commit tag:** `Day14_CI/CD_and_DR`

## What I completed
Designed the pipeline, per-service deployment strategies, multi-region topology, RPO/RTO, failover runbook, 7 chaos experiments and the cost model. Wrote 2 Dockerfiles and 10 K8s manifests.

## Key decision
No CPU limits on critical-path services. CFS throttling surfaces as tail latency, which is the exact metric under SLO.

## Blockers / risks
Cross-region RPO <1min is not achievable - synchronous replication over a 35ms RTT would add 70ms per write. Stated honestly as 10-30s async lag, recoverable from Kafka. Also: Indian data cannot fail over to Singapore under RBI residency.
