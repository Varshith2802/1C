# Day 05 — API Contracts

**Commit tag:** `Day05_API_Contracts`

## What I completed
Wrote the OpenAPI 3.0 spec (7 paths, 13 schemas) and validated it. Defined 6 gRPC services / 12 RPCs. Built the Kong routing table.

## Key decision
Money serialises as a decimal string, never a JSON number. JSON numbers are IEEE 754 doubles in most parsers and an authorisation amount must not round-trip through one.

## Blockers / risks
Day 5 heading in the brief reads 'OPENAI and Protobuf'. Candidate error E1.
