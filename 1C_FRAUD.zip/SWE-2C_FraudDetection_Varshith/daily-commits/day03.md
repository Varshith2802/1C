# Day 03 — C4 and SLAs

**Commit tag:** `Day03_C4_and_SLAs`

## What I completed
Finished C4 Level 2 and four Level 3 diagrams. Built the per-service SLA table and the hop-by-hop latency budget. Documented polyglot persistence.

## Key decision
THE finding of the project: the latency budget does not close for synchronous graph updates. 84ms + 52ms = 136ms against a 100ms gRPC budget.

## Blockers / risks
Brief's A2.5 decision SLA (<100ms) is tighter than its own A3.3 pipeline SLO (200ms) and has no percentile. Candidate error E3.
