# Day 08 — ML Architecture

**Commit tag:** `Day08_ML_Architecture`

## What I completed
Designed the ensemble, two-tier feature store, serving, deployment pipeline, monitoring and champion-challenger.

## Key decision
Weighted MAXIMUM, not average. Averaging dilutes an isolation forest correctly flagging a novel pattern with two supervised models that have no training data for it.

## Blockers / risks
PSI detects data drift, not concept drift. An adversary crafting statistically normal transactions produces PSI near zero with collapsing detection. Documented as a stated blind spot.
