# Day 11 — API Gateway

**Commit tag:** `Day11_API_Gateway`

## What I completed
Designed routing, 5 rate-limit tiers, circuit breaking and third-party access controls.

## Key decision
Rate-limit counters strictly synchronous through Redis. Local counting across 10 pods permits a 10x breach exactly when the limit matters.

## Blockers / risks
Adaptive limiting is attacker-triggerable - it can be used to DoS legitimate merchants. Added a 15-minute window, a 50% cap and a P1 page on activation.
