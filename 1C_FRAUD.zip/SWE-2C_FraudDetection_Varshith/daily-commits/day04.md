# Day 04 — Kafka Design

**Commit tag:** `Day04_Kafka_Design`

## What I completed
Designed 12 topics with derived partition counts. Wrote 17 Protobuf event schemas. Specified DLQ policy and Schema Registry compatibility.

## Key decision
Key everything on card_number_hash. Partition skew from high-volume cards is accepted because out-of-order velocity counting is silently wrong and skew is merely uneven.

## Blockers / risks
None.
