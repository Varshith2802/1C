# Day 12 — Monitoring

**Commit tag:** `Day12_Monitoring`

## What I completed
Specified 4 Grafana dashboards. Wrote 18 Prometheus alerts across P1-P4. Wrote 3 runbooks.

## Key decision
Burn-rate alerting, not threshold. A monthly error budget can be spent in four minutes; an alert on monthly exhaustion always fires too late.

## Blockers / risks
Did not produce dashboard JSON - specified only. Recorded as gap 3.
