# Day 07 — Rule Engine

**Commit tag:** `Day07_Rule_Engine`

## What I completed
Wrote the JSON Schema and 20 rules matching the brief's category distribution exactly. Designed lifecycle, simulation and per-rule monitoring.

## Key decision
Simulation replays T-120 to T-90 days, not the last 30. Chargeback labels take 30-90 days to mature; backtesting recent data overstates precision and the number looks excellent while meaning nothing.

## Blockers / risks
AMT-003 needed a txn_count guard - without it a new cardholder has near-zero variance and every second transaction is 5 sigma out.
