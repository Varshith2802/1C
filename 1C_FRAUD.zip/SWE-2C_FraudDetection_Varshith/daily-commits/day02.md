# Day 02 — Service Decomposition

**Commit tag:** `Day02_Service_Decomposition`

## What I completed
Grouped events into 10 bounded contexts. Produced the context map with relationship patterns. Drafted the service table and C4 Level 1.

## Key decision
Nine services, not twelve. Customer Profile and Reference Data stay bounded contexts but ship as libraries - each service hop costs ~2ms and the budget cannot spare it.

## Blockers / risks
Brief's saga (A1.5) references a Card Management Service absent from its own context list (A1.2). Recorded as candidate error E4.
