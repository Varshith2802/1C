# Bounded Context Map

## Contexts

| # | Context | Owned data | Publishes | Consumes |
|---|---|---|---|---|
| 1 | **Transaction Ingestion** | Raw + enriched transactions (PostgreSQL, partitioned by day) | `transactions.raw`, `transactions.enriched` | Channel adapters, enrichment providers |
| 2 | **Fraud Analysis — Rule Engine** | Rule definitions, versions, per-rule metrics | `fraud.rule.results` | `transactions.enriched` |
| 3 | **Fraud Analysis — Anomaly Detection** | Model registry, feature store (Redis) | `fraud.anomaly.scores` | `transactions.enriched` |
| 4 | **Fraud Analysis — Graph Analysis** | Property graph (Neo4j) | `fraud.graph.signals` | `transactions.enriched`, `graph.updates` |
| 5 | **Risk Scoring** | Decisions, weights, thresholds | `fraud.decisions`, `fraud.alerts` | All three analysis topics |
| 6 | **Case Management** | Cases, assignments, dispositions | `fraud.cases` | `fraud.alerts` |
| 7 | **Notification** | Templates, delivery receipts | `notifications.status` | `fraud.decisions`, `fraud.cases` |
| 8 | **Audit & Compliance** | Append-only audit chain | — (terminal) | `audit.events` (all topics) |
| 9 | **Customer Profile** | Behavioural profiles | `profile.updates` | `fraud.decisions` |
| 10 | **Reference Data** | BIN, MCC, watchlists, country risk | `reference.updates` | External feeds |

Contexts 9 and 10 are **not separate deployable services** — see
[Service Decomposition §2](04_SERVICE_DECOMPOSITION.md). A bounded context is a modelling
boundary; a service is a deployment boundary. Conflating them is how a team ends up with
thirty services and a latency budget that cannot close.

## Context map

```mermaid
graph TB
    subgraph Upstream
        RD[Reference Data]
        CP[Customer Profile]
    end
    TI[Transaction Ingestion]
    subgraph FraudAnalysis[Fraud Analysis]
        RE[Rule Engine]
        AD[Anomaly Detection]
        GA[Graph Analysis]
    end
    RS[Risk Scoring]
    CM[Case Management]
    NT[Notification]
    AU[Audit and Compliance]
    ACL[Anti-Corruption Layer]
    MONO[(Legacy Oracle Monolith)]

    TI -->|Customer-Supplier| RE
    TI -->|Customer-Supplier| AD
    TI -->|Customer-Supplier| GA
    RD -->|Shared Kernel: risk enums| RE
    CP -->|Customer-Supplier| AD
    RE -->|Published Language| RS
    AD -->|Published Language| RS
    GA -->|Published Language| RS
    RS -->|Customer-Supplier| CM
    RS -->|Conformist| NT
    CM -->|Conformist| NT
    RS -.->|audit.events| AU
    CM -.->|audit.events| AU
    RE -.->|audit.events| AU
    MONO <-->|Anti-Corruption Layer| ACL
    ACL --> TI
```

## Relationship patterns, and why each one

| Relationship | Pattern | Reasoning |
|---|---|---|
| Ingestion → all analysis | Customer-Supplier | Ingestion owns the enriched-transaction schema. Analysis services are downstream and cannot demand changes; schema evolution is backward-compatible or it does not ship |
| Analysis → Risk Scoring | Published Language | Each engine emits a score plus a **structured explanation**, not a bare number. Risk Scoring cannot construct a regulator-facing rationale from a float, so the explanation is part of the contract, not a log line |
| Risk Scoring → Notification | Conformist | Notification adapts to whatever Risk Scoring publishes. It has no leverage and should not pretend to |
| Reference Data → Rule Engine | Shared Kernel | Risk enumerations (severity levels, country tiers) are shared types. A shared kernel is a coupling cost accepted deliberately, because duplicating an enum across nine services guarantees they diverge |
| Everything → Audit | Published Language, terminal | Audit consumes and never emits. Nothing may depend on Audit's availability for a decision, or the audit trail becomes a latency contributor and then gets bypassed under load |
| Monolith ↔ platform | Anti-Corruption Layer | Oracle's `TXN_MASTER` model must not leak. The ACL is deleted at end of migration — it is scaffolding with an expiry date, and naming it as such is what stops it becoming permanent |

## Boundary decisions, including the ones against the brief

### Why Rule / Anomaly / Graph are three services and not one "Fraud Analysis"

They share a bounded context but have incompatible operational profiles:

| | Rule Engine | Anomaly Detection | Graph Analysis |
|---|---|---|---|
| Compute | CPU, in-memory | CPU/GPU, model-resident | I/O, graph traversal |
| Latency | p99 15 ms | p99 10 ms | p99 50 ms |
| Change cadence | Hourly (analysts) | Weekly (data science) | Monthly |
| Scaling trigger | Request rate | Request rate | Query complexity |
| Failure impact | Severe — no known-pattern detection | Moderate — fall back to rules | Low — fall back to score margin |

Different scaling profiles, different owners, different failure domains. That is the textbook
case for separate services and it holds here.

### Why Customer Profile and Reference Data are libraries plus a shared datastore

Both are read-mostly lookups on the critical path. Making them services adds a network hop
(~2 ms p99 each) to buy independent deployability of data that changes daily. The latency
budget (Master Architecture §3.4) does not have 4 ms to spare for that trade. They are
modelled as bounded contexts, implemented as Redis-backed client libraries with a shared
batch writer.

**The cost of this decision, stated plainly:** a schema change to the profile structure now
requires a coordinated release across every consuming service. That is real coupling and it
will hurt at least once. It is accepted because the alternative is failing the latency SLA on
every transaction, and a platform that is 4 ms too slow on 2.4 M transactions a day is not a
platform.

### Why there is no "Card Management Service"

The brief's Fraud Investigation Saga (§A1.5) orchestrates a "Card Management Service" that
appears in none of its bounded contexts. Card freeze and unfreeze are operations on the
**issuer's core banking system**, which is an external system, not a platform service. The
saga in [docs/08](08_EVENT_DRIVEN_ARCHITECTURE.md) models it as an external participant with
an explicit compensating call. See [ERROR_DETECTION.md E4](ERROR_DETECTION.md).

### Circular dependency check

Customer Profile consumes `fraud.decisions` and Anomaly Detection reads profile features —
a cycle if both were synchronous services. It is broken by direction: profile updates flow
**asynchronously** via Kafka, while reads are **synchronous** from Redis. The write path and
read path never meet. No synchronous cycle exists anywhere in the platform; the Day 2 review
checked this against the C4 Level 2 edge list.
