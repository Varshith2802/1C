# Graph-Based Fraud Detection Design

## 1. Property graph schema

### Nodes

| Label | Properties | Index |
|---|---|---|
| `Card` | card_hash, bin, issuer, product_type, created_at, status | UNIQUE card_hash |
| `Account` | account_id, type, status, opened_at, risk_tier | UNIQUE account_id |
| `Customer` | customer_hash, risk_tier, kyc_level, onboarded_at | UNIQUE customer_hash |
| `Device` | device_fingerprint, os, browser, first_seen, is_jailbroken | UNIQUE device_fingerprint |
| `IPAddress` | ip_hash, country, city, is_vpn, is_proxy, is_tor, asn | UNIQUE ip_hash |
| `PhoneNumber` | phone_hash, carrier, country, ported_at | UNIQUE phone_hash |
| `Email` | email_hash, domain, disposable, first_seen | UNIQUE email_hash |
| `PhysicalAddress` | address_hash, city, state, country, zip | UNIQUE address_hash |
| `Merchant` | merchant_id, mcc, name, risk_category, onboarded_at | UNIQUE merchant_id; FULLTEXT name |

Every identifier is a hash. The graph holds **no** cardholder PII in cleartext — a graph
database is a poor place for a PCI DSS scope boundary, so it is kept out of scope entirely.

### Relationships

| Type | From → To | Properties |
|---|---|---|
| `TRANSACTED_WITH` | Card → Merchant | timestamp, amount_minor, channel, decision |
| `SHARED_DEVICE` | Card → Device | first_shared_at, last_shared_at, txn_count |
| `USED_IP` | Card → IPAddress | timestamp, session_duration |
| `REGISTERED_PHONE` | Customer → PhoneNumber | registration_date |
| `REGISTERED_EMAIL` | Customer → Email | registration_date |
| `SHARED_ADDRESS` | Customer → PhysicalAddress | relationship_type, since |
| `SAME_BENEFICIARY` | Account → Account | transfer_count, total_minor |
| `LINKED_ACCOUNT` | Customer → Account | link_type |
| `OWNS` | Customer → Card | issued_at |

### Indexes

```cypher
CREATE CONSTRAINT card_hash_unique       IF NOT EXISTS FOR (c:Card)     REQUIRE c.card_hash IS UNIQUE;
CREATE CONSTRAINT device_fp_unique       IF NOT EXISTS FOR (d:Device)   REQUIRE d.device_fingerprint IS UNIQUE;
CREATE CONSTRAINT ip_hash_unique         IF NOT EXISTS FOR (i:IPAddress) REQUIRE i.ip_hash IS UNIQUE;
CREATE CONSTRAINT customer_hash_unique   IF NOT EXISTS FOR (c:Customer) REQUIRE c.customer_hash IS UNIQUE;
CREATE INDEX      txn_timestamp          IF NOT EXISTS FOR ()-[r:TRANSACTED_WITH]-() ON (r.timestamp);
CREATE INDEX      device_first_seen      IF NOT EXISTS FOR (d:Device)   ON (d.first_seen);
CREATE FULLTEXT INDEX merchant_name_ft   IF NOT EXISTS FOR (m:Merchant) ON EACH [m.name];
```

The relationship index on `timestamp` is what makes 180-day pruning and time-windowed queries
tractable; without it every temporal query degrades to a full relationship scan.

## 2. Cypher query patterns

### Q1 — Hops to known fraud (real-time, cached)

```cypher
MATCH (c:Card {card_hash: $card_hash})
MATCH (f:Card) WHERE f.status = 'CONFIRMED_FRAUD'
MATCH path = shortestPath((c)-[:SHARED_DEVICE|USED_IP|SHARED_ADDRESS*1..4]-(f))
RETURN length(path) AS hops,
       [n IN nodes(path) | labels(n)[0]] AS path_labels,
       [r IN relationships(path) | type(r)] AS path_rels
ORDER BY hops ASC LIMIT 1;
```

Expected: `hops: 2, path_labels: ['Card','Device','Card'], path_rels: ['SHARED_DEVICE','SHARED_DEVICE']`.
Risk contribution: 1 hop → 400, 2 hops → 250, 3 hops → 120, 4 hops → 40.

The `*1..4` bound is load-bearing. Unbounded traversal on a graph with hub nodes (a popular
merchant, a carrier-grade NAT IP) reaches most of the graph and takes minutes.

### Q2 — Shared-device ring (Louvain community detection, batch)

```cypher
CALL gds.graph.project('fraud-infra',
  ['Card','Device','IPAddress','PhysicalAddress'],
  {SHARED_DEVICE: {orientation:'UNDIRECTED'},
   USED_IP:       {orientation:'UNDIRECTED'},
   SHARED_ADDRESS:{orientation:'UNDIRECTED'}});

CALL gds.louvain.stream('fraud-infra', {maxIterations: 20})
YIELD nodeId, communityId
WITH communityId, collect(gds.util.asNode(nodeId)) AS members
WHERE size(members) >= 5
WITH communityId, members,
     size([m IN members WHERE m:Card]) AS cards,
     size([m IN members WHERE m:Device]) AS devices
WHERE cards >= 5 AND devices <= cards / 3     // many cards, few devices
RETURN communityId, cards, devices, [m IN members | coalesce(m.card_hash, m.device_fingerprint)] AS entities
ORDER BY cards DESC;
```

The `devices <= cards / 3` filter is the discriminator. Louvain alone finds any dense cluster,
including a legitimate family sharing a tablet. A ring's signature is *asymmetry*: many cards
concentrated on few pieces of infrastructure.

Modularity threshold for flagging: **≥ 0.65**, with the size and asymmetry filters above.
Modularity alone is a poor flag — a well-separated legitimate community scores high too.

### Q3 — Money mule detection (betweenness centrality)

```cypher
CALL gds.betweenness.stream('fund-flow')
YIELD nodeId, score
WITH gds.util.asNode(nodeId) AS n, score
WHERE n:Account AND score > $p99_threshold
MATCH (n)-[r:SAME_BENEFICIARY]-()
WITH n, score, count(r) AS degree, sum(r.total_minor) AS volume
WHERE degree < 20                        // low degree, high betweenness
RETURN n.account_id, score, degree, volume ORDER BY score DESC;
```

High betweenness with *low* degree is the mule signature: a small number of connections that
happen to be the only bridge between two clusters. High betweenness with high degree is just
a popular node.

### Q4 — Account farming (temporal growth)

```cypher
MATCH (d:Device)<-[s:SHARED_DEVICE]-(c:Card)
WHERE s.first_shared_at > datetime() - duration({days: 7})
WITH d, count(DISTINCT c) AS new_cards,
     min(s.first_shared_at) AS first, max(s.first_shared_at) AS last
WHERE new_cards > 10
RETURN d.device_fingerprint, new_cards,
       duration.between(first, last).hours AS window_hours
ORDER BY new_cards DESC;
```

More than 10 new card associations on one device in 7 days. `window_hours` matters: 12 cards
over 7 days may be a shared kiosk; 12 cards in 40 minutes is automation.

### Q5 — Triangulation topology (subgraph matching)

```cypher
MATCH (cardA:Card)-[:TRANSACTED_WITH]->(m1:Merchant),
      (cardB:Card)-[:TRANSACTED_WITH]->(m2:Merchant),
      (cardA)-[:SHARED_DEVICE]->(d:Device)<-[:SHARED_DEVICE]-(cardB),
      (m1)-[:SHIPS_TO]->(addr:PhysicalAddress)<-[:SHIPS_TO]-(m2)
WHERE cardA <> cardB AND m1 <> m2
RETURN d.device_fingerprint, addr.address_hash,
       collect(DISTINCT cardA.card_hash) + collect(DISTINCT cardB.card_hash) AS cards,
       collect(DISTINCT m1.merchant_id) + collect(DISTINCT m2.merchant_id) AS merchants;
```

### Fraud topology templates

| Template | Signature |
|---|---|
| **T1 Triangulation** | Two cards, shared device, two merchants, common shipping address (Q5) |
| **T2 Synthetic cluster** | ≥ 5 Customers sharing an address or phone, all `card_age < 120d`, all dormant then simultaneously active |
| **T3 Mule chain** | Path of ≥ 3 Accounts via `SAME_BENEFICIARY` within 48 h, each hop within 10% of the prior amount |

T2 is the ShieldPay crisis pattern, and it is the one no rule and no supervised model catches.

## 3. Update strategy: asynchronous, and why

| | Synchronous | Asynchronous (chosen) |
|---|---|---|
| Added decision latency | +52 ms (2 ms hop + 50 ms p99 query) | +1 ms (Redis read of cached signal) |
| Graph freshness | Always current | 1–5 s stale |
| Neo4j write coupling | Write on the authorisation path | Decoupled via Kafka |
| Failure blast radius | Neo4j outage degrades every decision | Neo4j outage degrades only graph signals |

**The decision is forced by arithmetic, not preference.** The synchronous path already runs
~84 ms p99 ([SLA §4.1](05_SLA_SPECIFICATION.md)). Adding 52 ms gives ~136 ms against a 100 ms
gRPC critical-path budget (§A1.4) and a 200 ms pipeline SLO with no remaining headroom for GC
pauses, connection-pool waits or a Neo4j leader re-election. Synchronous graph update is not
a trade-off available inside the stated budget; presenting it as an open choice would be
dishonest.

### What the staleness window costs

The first transaction of a *brand new* card that has never been seen has no graph signal —
the edge that would connect it does not exist for 1–5 seconds. A fraudster who knew this
could attempt to spend inside the window.

Three things bound that:

1. **The window is 1–5 seconds**, not minutes. Executing meaningful value inside it requires
   automation that itself triggers velocity rules VEL-001 and VEL-004.
2. **`graph_signal_age_seconds` is part of the decision contract** ([OpenAPI](../api-specs/openapi.yaml)).
   Risk Scoring adds a conservative margin when the signal is absent or stale rather than
   treating "no signal" as "no risk" — the failure mode that makes staleness dangerous is
   silently reading a missing signal as a clean one.
3. **The rule engine covers the simplest case synchronously.** DEV-002 (device shared across
   >5 cardholders in 7 days) is a single-hop graph query executed in Redis inside the latency
   budget. Multi-hop analysis is what runs asynchronously.

### Reconciliation

Since the graph is asynchronously derived, it can drift from the transactional record:

- **Daily reconciliation job** compares Neo4j edge counts against PostgreSQL per card for the
  prior 24 h; discrepancies above 0.01% raise P2 and trigger targeted replay from Kafka.
- **Kafka offsets are the source of truth for recovery.** The graph is fully rebuildable by
  replaying `transactions.enriched` from the 30-day retention window. Rebuild time for the
  full window is estimated at ~6 hours at 2,000 events/s — **an estimate, not a measurement**,
  and one of the first numbers that should be validated in a pre-production load test.

## 4. Pruning and read scaling

- Edges older than **180 days** pruned nightly, archived to S3 as Parquet. Without pruning,
  node degree grows without bound and traversal cost with it. A `Card` with 4,000 merchant
  edges makes every query through it slow.
- **Read replicas** for analytical work. Louvain over the full graph runs for minutes; running
  it on the primary would block the real-time lookups that must complete in milliseconds.
  Q1 hits the primary, Q2–Q4 hit replicas.
- Causal cluster: 3 core members (Raft) + 2 read replicas. Core majority survives one loss.

## 5. Honest limitation

Graph analysis detects **shared infrastructure**. A disciplined adversary using a distinct
device, IP, address and phone per synthetic identity produces a graph with no edges between
them and is invisible to every query here. Operational discipline is expensive and rings
degrade over time, which is why this works in practice — but the capability ceiling is real
and it is set by the adversary's tradecraft, not by the query design. Graph analysis is a
strong layer, not a complete one, and the risk register in the Board deck says so.
