# ML Serving and Anomaly Detection Architecture

## 1. The constraint that shapes everything: label lag

Confirmed fraud labels arrive from chargebacks **30–90 days** after the transaction. Every
design decision below follows from that one fact, and it deserves to be stated before the
architecture rather than buried in a monitoring subsection.

Consequences:

- **A supervised model cannot detect a novel attack while it is running.** The ShieldPay
  synthetic-identity ring aged accounts for 90 days and busted out in one. By the time labels
  existed, the money was gone and the ring had rotated infrastructure. No retraining cadence
  fixes this — the labels do not exist yet at any cadence.
- **Model performance cannot be measured in real time.** What is measurable today is score
  distribution, feature drift and analyst disposition; actual precision and recall are known
  only in arrears.
- **Therefore ML carries volume, not novelty.** Rules and graph analysis carry novel-attack
  detection because they need no labels. Presenting ML as the primary defence against
  emerging fraud would be the same mistake the monolith made with a 6-month-old logistic
  regression.

## 2. Ensemble

| Model | Type | Role | Latency |
|---|---|---|---|
| **Champion: LightGBM** | Supervised GBDT | Primary score — known patterns, high volume | 4 ms |
| **Isolation Forest** | Unsupervised | Novelty without labels | 2 ms |
| **Sequence model (GRU)** | Supervised, transaction history | Temporal patterns trees miss | 6 ms |

Combination is **weighted maximum**, not weighted average:
`ml_score = max(0.6 × gbdt, 0.8 × isoforest, 0.7 × sequence)` scaled to 0–1000.

Maximum rather than average because the three models have different coverage. Averaging
means an isolation forest correctly screaming about a never-before-seen pattern gets diluted
by two supervised models that have no opinion because the pattern is not in their training
data. The cost of maximum is a higher false positive rate — accepted, and the reason
isolation forest's weight (0.8) sits below its raw confidence.

Inference is parallel; total is max(4, 2, 6) = 6 ms, plus ~3 ms for SHAP and feature assembly,
inside the 10 ms p99 budget.

## 3. Feature store

Two tiers, both in Redis, read in a single pipelined `MGET`:

| Tier | Computed | Freshness | Examples |
|---|---|---|---|
| **Batch** | Nightly Spark → PostgreSQL → Redis | ≤ 24 h | 90-day mean amount, top-10 merchants, card age, POS share |
| **Real-time** | Kafka Streams on `transactions.enriched` | < 1 s | 1/5/10/30/60-min velocity, distinct merchants, distinct countries |

~200 features across six families (transaction, cardholder, velocity, distance,
device/network, derived). Full definitions in
[`configs/feature-definitions.yaml`](../configs/feature-definitions.yaml).

**Training/serving skew is the failure mode to guard against.** A velocity feature computed
one way in a Spark training job and another way in a Kafka Streams serving job produces a
model that performs well offline and poorly in production, and the discrepancy is invisible
in every offline metric. Mitigation: the two-tier definitions are declared once in
`feature-definitions.yaml` and both paths generate from that declaration; a daily job samples
1,000 live transactions, recomputes features through the training path and alerts on any
divergence above 0.1%.

**Degraded mode:** on a Redis miss or timeout, population-average defaults are substituted and
`degraded_features=true` propagates into the decision. Risk Scoring lowers its reliance on the
ML contribution accordingly rather than treating a defaulted score as a confident one.

## 4. Serving

ONNX Runtime behind FastAPI. Chosen over TensorFlow Serving (models are GBDT, not TF) and
Triton (GPU scheduling buys nothing for tree ensembles at this size). Models load at container
start and are warmed with 100 synthetic requests before the readiness probe passes — a
cold-start p99 of 400 ms on the first real transaction would otherwise blow the SLO at every
deployment.

## 5. Deployment pipeline

```
train (historical, labels mature) → validate (holdout + temporal holdout)
  → stage (pre-production, replay) → shadow 7d → canary 5% → 25% → 50% → 100%
```

**Temporal holdout, not just random holdout.** Random splits leak future information into
training via velocity features and inflate validation metrics. The holdout must be a later
time period than training, or validation measures the wrong thing.

Canary promotion is gated on error rate, latency and business metrics (detection proxy, FP
rate from analyst dispositions) compared against champion. Automatic rollback on degradation
beyond threshold.

## 6. Monitoring

| Signal | Method | Cadence | Alert |
|---|---|---|---|
| Data drift | PSI per feature | Hourly | PSI > 0.25 → P3 |
| Prediction drift | KS test on score distribution | Hourly | p < 0.01 → P3 |
| Performance | Precision/recall vs mature labels | Monthly | Detection < 90% → P2 |
| Skew | Training-path recompute on live sample | Daily | > 0.1% divergence → P2 |
| Latency | p99 inference | Continuous | > 10 ms → P2 |

**PSI has a specific blind spot worth stating:** it detects *data* drift — inputs changing
distribution. It does not detect *concept* drift, where inputs look identical but their
relationship to fraud has changed. An adversary who learns the model and crafts transactions
that look statistically normal produces PSI ≈ 0 and a collapsing detection rate. That is why
detection rate against mature labels remains the authoritative metric despite its 90-day lag,
and why it is never replaced by drift monitoring as a proxy.

## 7. Retraining triggers

Retrain when PSI > 0.25, **or** weekly detection rate < 90%, **or** every 90 days regardless.
The fixed cadence matters most: drift-triggered retraining alone never fires under concept
drift, which is exactly the case where retraining is most needed.

## 8. Champion–challenger

Challengers receive identical input via the shadow path and never influence decisions.
Minimum 7-day evaluation; promotion requires superiority on precision at fixed recall across
**every market segment**, not aggregate. A challenger better in aggregate but worse in one
market has learned a segment imbalance, and promoting it degrades service for that market
while the top-line number improves.

## 9. Explainability

TreeSHAP over the GBDT gives exact per-feature attribution in ~3 ms. The top five
contributions, signed and named, travel with the score into the decision and the audit chain.

A regulator or a customer asking "why was my transaction declined" receives named features and
their contributions, not a score. The isolation forest is the weak point — it has no SHAP
equivalent, so its contribution is explained by nearest-neighbour reference ("this transaction
resembles a known-anomalous cluster on amount and merchant novelty"), which is weaker
explanation than the GBDT provides. Stated rather than glossed, because a decision driven
primarily by the isolation forest is genuinely less explainable, and that fact should inform
the Board's view of the ensemble weighting.
