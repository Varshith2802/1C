# API Gateway and Rate Limiting

Configuration: [`api-specs/gateway-routing.yaml`](../api-specs/gateway-routing.yaml).

## 1. Gateway responsibilities

| Concern | Implementation |
|---|---|
| TLS termination | TLS 1.3 only; TLS 1.2 and below refused |
| Authentication | RS256 JWT (`exp`, `nbf` verified); OAuth 2.0 client credentials for M2M; API keys for legacy acquirer integrations only, with a documented sunset date |
| Authorisation | JWT claims → RBAC roles → Kong ACL per route |
| Request validation | OpenAPI schema validation before any backend call |
| Transformation | REST/JSON ↔ gRPC/Protobuf transcoding |
| Response caching | 5 s on risk-score lookups, 30 s on dashboard |
| Rate limiting | Five tiers, Redis-backed (§2) |
| Correlation | `X-Trace-Id` generated at edge, propagated to the audit chain |

## 2. Five rate-limit tiers

Rate limiting here is a **fraud control**, not only a capacity control. Enumeration attacks
(§A2.1) are executed through the transaction endpoint, so the gateway is the first place the
attack is visible.

| Tier | Scope | Limit | Purpose |
|---|---|---|---|
| 1 | Per merchant | 1,000 TPS large acquirer / 100 TPS small | Contracted throughput |
| 2 | Per IP | 50 req/min | Distributed attack detection |
| 3 | Per endpoint | POST /transactions 1,000 TPS; POST /rules 30/min | Protects expensive write paths |
| 4 | Global | 50,000 TPS | Backend overload protection |
| 5 | **Adaptive** | Tier 1 halved when platform fraud rate > 5% | Attack response |

### Why counters are strictly synchronous

Kong's `sync_rate: -1` forces every increment through Redis rather than allowing local
counting with periodic sync. Local counting across 10 gateway pods with a 1,000 TPS per-merchant
limit permits up to 10,000 TPS during the sync interval — a tenfold breach precisely when the
limit matters most. The cost is ~1 ms of Redis round trip per request, which the budget
accommodates.

### Adaptive limiting, and its danger

Tier 5 halves per-merchant limits when the platform-wide fraud rate exceeds 5%. This is the
most powerful and the most dangerous control in the gateway, because **an attacker who can
raise the observed fraud rate can trigger a self-inflicted denial of service against
legitimate merchants**.

Three guards:

1. Fraud rate is computed over a 15-minute window, not instantaneously, so a brief spike
   cannot trip it.
2. Reduction is capped at 50% and never falls below a contractual floor.
3. Activation raises a **P1 page**. Adaptive limiting is a human-supervised control that acts
   first and asks second, not an autonomous one — an automated control that degrades paying
   customers must never operate unobserved.

`X-RateLimit-Limit`, `-Remaining` and `-Reset` are returned on every response so clients can
self-regulate rather than discovering the limit by hitting it.

## 3. Circuit breaking at the gateway

Outlier detection ejects a backend after 5 consecutive 5xx (3 for anomaly-detection, where a
bad model pod should leave quickly), with `maxEjectionPercent: 50`. The cap matters: ejecting
100% of instances converts a partial degradation into a total outage, which is the failure
mode circuit breaking exists to prevent.

## 4. Third-party access control (Target lesson)

The Target breach began at an HVAC vendor with network access for billing. Applied here:

- Every third-party integration receives a **scoped OAuth client** limited to specific routes,
  never a general credential.
- API usage is **baselined per client**; access outside normal hours or to unusual endpoints
  raises P2. A vendor's client suddenly reading bulk data at 03:00 is the signal Target had
  no mechanism to see.
- Third-party clients are **network-isolated** from the decision path — they reach the gateway
  and nothing else.
- Credentials expire on a fixed schedule with no auto-renewal; a dormant integration's
  credentials die by default rather than persisting indefinitely.
