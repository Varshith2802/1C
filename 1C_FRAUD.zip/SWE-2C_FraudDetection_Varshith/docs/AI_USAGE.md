# AI-Assisted Development Disclosure

Required by Part E, §E5.

## Tools used

Claude (Anthropic) was used throughout for research synthesis, drafting and the generation of
configuration artefacts.

## What AI produced

| Area | AI contribution | Human contribution |
|---|---|---|
| Domain glossary | First-pass definitions | Selection of terms, correction of payments-specific usage |
| C4 diagrams | Mermaid syntax and layout | Service boundaries, communication patterns, the decision to use nine services |
| OpenAPI / Protobuf | Schema scaffolding | Endpoint selection, error semantics, the decision to serialise money as a string |
| Rule definitions | YAML structure and initial thresholds | Rule selection, threshold reasoning, the guard conditions on AMT-003 and BEH-002 |
| Istio / Kubernetes | Manifest boilerplate | Security posture, the no-CPU-limit decision, probe design, network policies |
| Cypher queries | Query syntax | Query patterns, the asymmetry filter in Q2, the bounded traversal depth in Q1 |
| Prose | Drafting | Every argument, every trade-off, every stated limitation |

## Verified independently

Every factual claim that carries design weight was checked rather than accepted:

- **Latency arithmetic** (SLA §4.1–4.3) — computed by hand; it is the basis for the
  asynchronous-graph decision and could not be taken on trust.
- **Rule distribution** — validated programmatically against the brief's Day 7 specification
  (5/3/3/3/2/2/2 = 20). Confirmed by script, not by counting.
- **Schema validity** — OpenAPI validated with `openapi-spec-validator`; the rule JSON Schema
  checked as valid Draft-07; all 20 rules validated against it; every YAML manifest parsed.
- **Case study facts** — Target (2013), Cosmos Bank (2018), Wirecard (2020), Netflix
  architecture — checked against the brief and against independent knowledge, which is how U6
  and E3 were found.
- **Cost figures** — derived from the resource requests in `samples/k8s/` against published
  list prices, and labelled as estimates rather than quotes.

## Where AI output was rejected

Recorded because "reviewed and customised" means little without examples:

1. **Twelve services.** The initial decomposition split enrichment, customer profile and
   reference data into separate services to reach the top of the brief's 8–12 range. Rejected
   after the latency budget showed each hop costs ~2 ms against an already-tight 84 ms path.
   Nine services, with two bounded contexts implemented as libraries. Reasoning in
   [Service Decomposition §2](04_SERVICE_DECOMPOSITION.md).

2. **Synchronous graph updates.** The first draft presented synchronous and asynchronous graph
   updating as a balanced choice, mirroring the brief's framing. Arithmetic showed synchronous
   adds 52 ms to an 84 ms path, exceeding the 100 ms gRPC budget outright. It is not a choice
   inside the stated constraints, and presenting it as one would have been misleading.

3. **Weighted-average ensemble.** Proposed as the standard combination. Rejected because
   averaging dilutes an isolation forest correctly flagging a novel pattern with two supervised
   models that have no training data for it. Weighted maximum instead, with the false-positive
   cost acknowledged.

4. **"Achieves 95% detection rate."** Drafted as an accomplishment. Corrected to a target with
   a measurement methodology — the platform has processed no transactions, and detection rate
   cannot be known before it has.

5. **Uniform fail-closed on rule-engine outage.** Rejected: declining 28 TPS of legitimate
   traffic creates a customer-service incident within minutes. Replaced with a value-banded
   policy (fail closed above ₹50,000, open below).

6. **A "Card Management Service"** was initially drafted into the saga, following the brief.
   Removed once it became clear no bounded context defines it — this became E4.

## Ownership

Every design decision, trade-off and stated limitation in this repository is one I can explain
and defend under questioning. Where a number is an estimate rather than a measurement, the
document says so — that distinction is the thing most worth preserving under Board examination,
and it is the thing an AI draft most readily erases.
