# Error Detection

Day 15 requires locating **five errors embedded in the project brief**. Unlike the sibling
brief 463549B, these are not flagged inline — the document says only that five exist.

Five are identified below, each with the location, the correction, and the place in this
repository where the correction is acted upon. Six further inconsistencies follow; they are
not flagged by the brief and may not be among the intended five, but they are real and a
reviewer should see them.

---

## E1 — "OPENAI" for "OpenAPI"

**Location:** Part D, Day 5 heading: *"API Contract Design (OPENAI and Protobuf)"*

**Correction:** The standard is **OpenAPI 3.0**, a specification format for HTTP APIs
maintained by the OpenAPI Initiative under the Linux Foundation. OpenAI is an unrelated
artificial-intelligence company with no connection to API specification.

The body text underneath uses "OpenAPI 3.0" correctly throughout, and the Day 5 deliverable
list and the Part E tooling table both name Swagger Editor and Redoc — OpenAPI tools. The
heading is the only occurrence.

**Acted on in:** [`api-specs/openapi.yaml`](../api-specs/openapi.yaml) — a genuine OpenAPI
3.0.3 specification, validated with `openapi-spec-validator` (0 errors), covering all seven
endpoints the brief requires.

---

## E2 — "Machine Laarnign"

**Location:** Part A, §A2.3 heading: *"Anomaly Detection And Machine Laarnign"*

**Correction:** **"Machine Learning"**. A double transposition (`Le`→`La`, `ni`→`ig`).

Worth stating why a typo counts as a planted error rather than sloppiness: §A2.3 is the
section heading for the entire ML discipline in a document that will be read by assessors and
indexed by search. It is also the only misspelled heading in a 43-page document that is
otherwise clean, which is the signature of a deliberate insertion rather than an accident.

**Acted on in:** [`docs/10_ML_ARCHITECTURE.md`](10_ML_ARCHITECTURE.md), which covers the §A2.3
content under a correctly spelled heading.

---

## E3 — The decision SLA is tighter than the pipeline that produces it

**Location:** three sections that cannot all be true.

| Section | Statement |
|---|---|
| §A2.5 risk-scoring table | Auto-Approve SLA **< 100 ms**; Auto-Decline SLA **< 100 ms** |
| §A3.3 key metrics | Transaction processing latency **p99 < 200 ms for the entire pipeline** |
| §A1.4 | gRPC critical path **combined budget of 100 ms at p99** |

**Two distinct defects:**

**(a) The decision SLA carries no percentile.** "< 100 ms" for an auto-approve is not a
measurable commitment. Is that a mean, a p95, a p99, or an absolute ceiling? Every one of
those is a different engineering target with a different cost, and the difference between a
100 ms mean and a 100 ms p99 is roughly an order of magnitude in infrastructure. Every other
latency figure in the brief is expressed as a percentile; this table is not.

**(b) Read as a p99 it contradicts §A3.3.** A decision is the pipeline's output. If the
pipeline is permitted 200 ms at p99, the decision it produces cannot be delivered in under
100 ms at p99. The two figures describe the same measurement and disagree by a factor of two.

Additionally, §A1.4's 100 ms gRPC budget and §A3.3's 200 ms pipeline SLO are consistent only
if gateway, ingestion and enrichment consume the other 100 ms — which happens to be roughly
correct in this design (enrichment alone is 30 ms), but the brief never states the
decomposition, so the consistency is coincidental rather than specified.

**Correction:** the pipeline SLO governs. The §A2.5 column should read **"p50 < 50 ms,
p99 < 200 ms"** for both auto-approve and auto-decline, consistent with §A3.3. The step-up
(< 5 s) and manual review (< 4 h) rows are *not* latency SLAs — they are round-trip and case
SLAs — and the table conflates three different kinds of time into one column.

**Acted on in:** [`docs/05_SLA_SPECIFICATION.md §4.4`](05_SLA_SPECIFICATION.md), which
reconciles the three figures and provides a hop-by-hop budget totalling ~84 ms p99. That
budget is also what demonstrates graph analysis cannot be synchronous — so this error is not
cosmetic; resolving it changes the architecture.

---

## E4 — A saga orchestrated across a service that does not exist

**Location:** §A1.5, the Fraud Investigation Saga:

> "(1) **Card Management Service** freezes the card (compensating action: unfreeze)"

**The problem:** §A1.2 enumerates the bounded contexts — Transaction Ingestion, Fraud
Analysis, Risk Scoring, Case Management, Notification, Audit and Compliance, Customer Profile,
Reference Data. There is no Card Management context. §A1.3's Level 2 guidance lists the
services to be drawn, and it is not there either. Part D's Day 2 asks for 8–12 services
derived from those contexts; a service appearing only inside a saga example has no context to
derive it from.

**Why it is not merely a naming slip:** the operation described — freezing and unfreezing a
card — is a change to card state, and card state is owned by the **issuer's core banking
system**, which §A1.3 lists as an *external* system. Modelling it as an internal microservice
implies the platform owns card lifecycle, which contradicts the Level 1 context diagram and
would put a fraud detection platform in the business of being a card management system.

The distinction has real design consequences. An internal service is called over mesh gRPC
with a 15 ms deadline. An external mainframe MQ integration needs an anti-corruption layer, a
circuit breaker, a much longer timeout, and a compensating action that is **idempotent and
retried**, because a failed unfreeze leaves a real customer with a dead card.

**Correction:** the saga participant is the external Core Banking System, reached through the
anti-corruption layer.

**Acted on in:**
[`docs/08_EVENT_DRIVEN_ARCHITECTURE.md §2.2`](08_EVENT_DRIVEN_ARCHITECTURE.md) and
[`diagrams/saga-fraud-investigation.mmd`](../diagrams/saga-fraud-investigation.mmd), where the
CBS is drawn as an external participant with an idempotent, retried unfreeze compensation that
raises P1 on persistent failure. [`docs/03_BOUNDED_CONTEXTS.md`](03_BOUNDED_CONTEXTS.md)
records why no Card Management context was created.

---

## E5 — Three mutually inconsistent project naming schemes

**Location:** three places that disagree.

| Location | Scheme |
|---|---|
| Part E, §E3 | Repository name: `SWE-2C_FraudDetection_[YourFullName]` |
| Part C, §C1–C2 | "Architectural Lessons **For SWE-2C**" |
| Part D, Submission Instructions | `ProjectCode_YourName_DeliverableName`, example `201169C_RahulShah_MainReport` |
| The document itself | Filename project code **463549C** |

Four identifiers for one project: `SWE-2C`, `463549C`, `201169C` and the generic
`ProjectCode`. The worked example uses `201169C`, which belongs to neither this project nor
the `SWE-2C` scheme.

**Why it matters beyond tidiness:** §E3 makes the repository name a graded deliverable, and
Day 1 of the sibling brief 463549B states that failing to create the repository correctly is
grounds for automatic disqualification. A candidate following §E3 produces
`SWE-2C_FraudDetection_Varshith`; a candidate following the Submission Instructions produces
`463549C_Varshith_MainReport`. One of them is wrong and the brief does not say which.

**Correction / resolution used here:** the **repository** follows §E3, because §E3 is the
section that specifically governs repository naming and also fixes the directory structure.
**Submitted files** follow the Part D convention with the document's own project code:
`463549C_Varshith_<DeliverableName>`. Flagged to the supervisor rather than silently guessed.

---

# Further inconsistencies, not flagged by the brief

These are not among the five planted errors as far as can be determined, but each is a real
defect a reviewer should know about.

### U1 — Monolith arithmetic does not close
§B1.1: the monolith was "originally built in 2012 and has accumulated 1.2 million lines of
Java code **over 12 years**". §B1.2 places the crisis in **Q3 2025**. 2012 to 2025 is 13
years. Minor, but it is the kind of detail a CTO checks.

### U2 — Two incompatible 1000-point rubrics
§B1.4 awards 1000 points across six challenge levels (150+200+200+150+150+150 = 1000, which
sums correctly). Part F states a 1000-point rubric across **seven dimensions** — Problem
Understanding, Solution Quality, Research & Analysis, Presentation & Clarity, Innovation &
Creativity, Feasibility & Practicality, CV alignment. These are different axes over the same
total, and a candidate optimising for one is not optimising for the other.

### U3 — Distroless base images cannot run a shell health check
§A4.1 requires "distroless or Alpine-based" images **and** "a health check endpoint
(/healthz)". Distroless images contain no shell, so a Dockerfile `HEALTHCHECK` using
`CMD curl` or `CMD /bin/sh` silently never works. The health check must be a Kubernetes
`httpGet` probe instead. This combination is a very common production defect — the container
reports healthy because the check never executes. Handled explicitly in
[`samples/docker/Dockerfile.rule-engine`](../samples/docker/Dockerfile.rule-engine) with a
comment, and probes defined in [`samples/k8s/`](../samples/k8s/).

### U4 — The RBI card-fraud reporting threshold is stated without a source
§A2.5 gives "2 lakh INR for card fraud" as the RBI reporting threshold. RBI's fraud-reporting
framework uses several thresholds by fraud category and reporting instrument, and the figure
does not obviously correspond to a published one. The architecture makes the threshold
**configurable** in Reference Data rather than hard-coding it, so a regulatory change is a
data update. Flagged to Compliance for confirmation against the current Master Direction.

### U5 — Retention periods disagree between sibling briefs
This brief states RBI retention of **7 years** (§A1.2, §C4). The sibling brief 463549B cites
clause 10.3 of the RBI Master Direction on Payment Aggregators as **10 years**. Both appear in
Zetheta project documents describing Indian payments regulation. Internally, 463549C is
consistent at 7 years, so this build uses 7 and flags the discrepancy — the difference is
three years of storage cost and a compliance exposure if the lower figure is wrong.

### U6 — Target breach dates are compressed
§C1 gives "November–December 2013" and a "19-day period". The precise timeline is: malware
installed **15 November 2013**; active exfiltration **27 November – 15 December**; public
disclosure **19 December**. The 19-day figure matches the theft window, but the sentence
attributes it to the period "before the breach was detected and contained", which merges the
theft window with detection and containment. The distinction is the lesson: the gap between
installation and theft is the detection window that was missed, and the gap between the end
of theft and disclosure is a separate notification failure. The same case study appears in
sibling brief 463549B, where the dates *are* flagged as a deliberate error — which suggests
this occurrence may be intentional here too.
