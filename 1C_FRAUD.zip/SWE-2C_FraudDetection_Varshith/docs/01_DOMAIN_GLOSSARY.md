# Domain Glossary

62 terms. Definitions are written for an engineer joining the platform team who has no
payments background, because that is who actually reads a glossary.

## Card and payment mechanics

| Term | Definition |
|---|---|
| **PAN** | Primary Account Number — the 13–19 digit number embossed on a card. Under PCI DSS Req 3 it may be stored only encrypted or truncated; this platform stores only a keyed hash and the last four digits. |
| **BIN / IIN** | Bank Identification Number — first 6–8 digits of the PAN, identifying the issuer, card product and country. Used for routing and as a risk feature. RuPay holds its own BIN ranges alongside Visa and Mastercard. |
| **MCC** | Merchant Category Code — 4-digit ISO 18245 code classifying a merchant's line of business. 7995 gambling, 4829 wire transfer, 6051 quasi-cash/crypto, 6050 quasi-cash. |
| **CVV / CVV2** | Card Verification Value. CVV1 is on the magnetic stripe; CVV2 is printed and used for CNP. Never storable post-authorisation under any circumstances. |
| **EMV** | The chip standard (Europay/Mastercard/Visa). Generates a unique cryptogram per transaction, which is why counterfeit fraud collapsed in chip markets and migrated to CNP. |
| **Magnetic stripe fallback** | Terminal accepting a stripe read when the chip fails. A known attack surface: forcing fallback defeats EMV. |
| **Contactless / tap-to-pay** | NFC transaction, typically below a floor limit with no PIN. Convenience traded against a bounded loss per tap. |
| **Card-Present (CP)** | The card or its clone was physically at the terminal. |
| **Card-Not-Present (CNP)** | E-commerce, mobile, MOTO. Roughly 75% of global card fraud. |
| **MOTO** | Mail Order / Telephone Order — a CNP channel with no cardholder device to fingerprint. |
| **Authorisation** | Real-time approve/decline decision. The only moment the fraud engine can actually stop the money. |
| **Clearing / Settlement** | Later movement of funds. Fraud found here is a recovery problem, not a prevention one. |
| **Chargeback** | Cardholder-initiated reversal. The primary source of confirmed fraud labels, arriving 30–90 days after the transaction. |
| **Interchange** | Fee paid by acquirer to issuer per transaction. Sets the economic ceiling on what fraud prevention may cost. |
| **Acquirer** | The merchant's bank. |
| **Issuer** | The cardholder's bank. ShieldPay is an issuer. |
| **Tokenisation** | Replacing a PAN with a surrogate token. RBI mandated card-on-file tokenisation from October 2022, which broke every model that used raw PAN as a feature. |
| **AFA** | Additional Factor of Authentication — RBI-mandated second factor for online card transactions in India, usually SMS OTP. |
| **UPI** | Unified Payments Interface. India-specific, 10 bn+ transactions/month, with its own fraud vocabulary: fake collect requests, malicious QR, PIN phishing. |
| **IMPS / NEFT / RTGS** | Indian interbank rails: immediate, half-hourly batch, and real-time gross settlement respectively. |
| **SWIFT** | Interbank messaging network. Not a payment rail itself — a messaging layer, which is exactly how Cosmos Bank was robbed through it. |
| **Nodal / Escrow account** | Account holding customer funds in transit. |

## Fraud typology

| Term | Definition |
|---|---|
| **Account Takeover (ATO)** | Attacker gains control of a legitimate account using stolen credentials. Distinguished from card fraud because the account's own history is the attacker's camouflage. |
| **Enumeration attack** | Automated testing of many stolen PANs with small-value transactions to find live cards. Signature: high volume, low value, high decline rate, few distinct merchants. |
| **Friendly fraud / first-party fraud** | The legitimate cardholder disputes a valid transaction. Indistinguishable from normal behaviour at authorisation time — no real-time control catches it. |
| **Triangulation fraud** | Fraudster runs a storefront, takes real orders, fulfils them with stolen cards. The victim merchant sees a normal-looking sale. |
| **Synthetic identity** | Fabricated identity built from real and invented data, aged for months before the bust-out. The ShieldPay crisis case. |
| **Bust-out** | Coordinated maximum-value spend across aged accounts, executed simultaneously to beat per-account controls. |
| **Money mule** | Account used to move fraud proceeds. In graph terms, a high-betweenness bridge node. |
| **Skimming** | Capturing card data at a compromised terminal or ATM. |
| **BlackPOS** | Memory-scraping POS malware family; the Target breach variant. |
| **SIM-swap** | Porting a victim's number to attacker-controlled SIM to intercept OTP. Defeats AFA entirely. |
| **Card-never-received** | Interception of a newly issued card in the post. |
| **Fraud ring** | Organised group sharing infrastructure — devices, addresses, IP subnets, phone numbers. Shared infrastructure is what makes graph analysis work. |

## Detection and modelling

| Term | Definition |
|---|---|
| **Detection rate / recall** | Fraction of actual fraud correctly flagged. Target > 95%. |
| **False positive rate (FPR)** | Fraction of legitimate transactions incorrectly flagged. Target < 0.5%. At 2.4 M txn/day, each 0.1% of FPR is 2,400 angry customers daily — which is why the metric is expressed per-day, not as a percentage, in the Board deck. |
| **Precision** | Fraction of flagged transactions that were actually fraud. Low precision is what causes the alert fatigue that sank Target. |
| **Velocity feature** | Count or sum over a time window for an entity (card, device, merchant). |
| **Feature store** | Serving layer for pre-computed features. Two tiers here: batch (daily Spark, Redis-synced) and real-time (Kafka Streams, Redis with TTL). |
| **Isolation Forest** | Unsupervised anomaly detector; anomalies need fewer random partitions to isolate. |
| **Autoencoder** | Network trained to reconstruct normal traffic; high reconstruction error implies anomaly. |
| **SHAP** | Shapley additive explanations — per-feature attribution for a single prediction. The mechanism by which an ML decision becomes explainable to a regulator. |
| **LIME** | Model-agnostic local explanation via a surrogate linear model. |
| **PSI** | Population Stability Index — distribution shift between training and live feature data. Alert at PSI > 0.25. |
| **KS test** | Kolmogorov–Smirnov — distribution comparison, used here for prediction (score) drift. |
| **Champion / Challenger** | Production model versus a shadow model receiving identical input but not influencing decisions. |
| **Concept drift** | The relationship between features and fraud changes because adversaries adapt. Distinct from data drift, and more dangerous: the inputs look fine. |
| **Label lag** | Delay between a transaction and its confirmed fraud label. 30–90 days here, from chargebacks. The single most consequential constraint on supervised learning in this domain. |
| **Class imbalance** | Fraud is ~0.1% of transactions; naive accuracy is a meaningless metric. |
| **Louvain** | Modularity-optimising community detection. Finds fraud rings as densely-connected clusters. |
| **PageRank** | Centrality measure identifying influential nodes — shared devices and IPs in a fraud context. |
| **Betweenness centrality** | Measures how often a node sits on shortest paths. High betweenness with low degree is the money-mule signature. |
| **Subgraph matching** | Matching a known fraud topology template against the live graph. |
| **Index-free adjacency** | Neo4j's storage model: relationships are pointers, so traversal cost is independent of total graph size. |

## Architecture

| Term | Definition |
|---|---|
| **Bounded context** | DDD unit — a cohesive business area with its own ubiquitous language and data. |
| **Anti-corruption layer** | Translation layer preventing a legacy model leaking into new services. Here, the adapter to the Oracle monolith. |
| **Strangler Fig** | Incremental migration: new capability as services, monolith retired module by module. |
| **Saga** | Sequence of local transactions with compensating actions, replacing distributed transactions. |
| **Orchestration vs choreography** | Central coordinator versus services reacting to events. Orchestration for investigation workflows; choreography for enrichment. |
| **CQRS** | Separating the write model from read models, so analytics never contends with the decision path. |
| **Event sourcing** | State as an append-only event sequence. Used for Audit only. |
| **Idempotency key** | Client-supplied key making a retried request safe. Mandatory on POST /transactions. |
| **DLQ** | Dead-letter queue for messages that fail processing after N retries. |
| **Circuit breaker** | Fails fast to an unhealthy dependency, giving it room to recover. |
| **Bulkhead** | Resource isolation so one saturated dependency cannot exhaust shared thread pools. |
| **Backpressure** | Propagating "slow down" upstream rather than buffering until collapse. |
| **mTLS** | Mutual TLS — both parties authenticate. The zero-trust primitive in the mesh. |
| **Error budget** | Allowed unreliability under an SLO. Exhaustion freezes deployments. |
| **RPO / RTO** | Recovery Point Objective (tolerable data loss) / Recovery Time Objective (tolerable downtime). |
| **Consumer lag** | Unprocessed messages per Kafka partition. The platform's primary saturation signal. |
