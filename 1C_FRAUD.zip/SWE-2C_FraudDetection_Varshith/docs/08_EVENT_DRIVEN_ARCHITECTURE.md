# Event-Driven Architecture Specification

Topic topology: [`configs/kafka/topics.yaml`](../configs/kafka/topics.yaml).
Event schemas: [`api-specs/events.proto`](../api-specs/events.proto).

## 1. Event Storming — 56 domain events

Notation: **Command** → *Event* (aggregate) → Policy.

### Ingestion (aggregate: Transaction)
1. `SubmitTransaction` → *TransactionReceived*
2. → *TransactionValidated*
3. → *TransactionRejectedInvalid*
4. → *DuplicateTransactionDetected* (idempotency key replay)
5. → *TransactionNormalised*
6. `EnrichTransaction` → *DeviceSignalsAttached*
7. → *GeoSignalsAttached*
8. → *ProfileSignalsAttached*
9. → *EnrichmentProviderTimedOut* → Policy: proceed with defaults, flag degraded
10. → *EnrichmentCircuitOpened*
11. → *TransactionEnriched*
12. → *PanTokenised*

### Rule evaluation (aggregate: RuleEvaluation)
13. `EvaluateRules` → *RuleEvaluationStarted*
14. → *RuleTriggered* (one per firing rule)
15. → *RuleShortCircuited*
16. → *RuleEvaluationCompleted*
17. → *RuleEvaluationTimedOut* → Policy: fail closed above ₹50k, open below
18. → *RulesetReloaded*
19. → *RulesetReloadFailed*

### Anomaly detection (aggregate: AnomalyAssessment)
20. `ScoreTransaction` → *FeaturesRetrieved*
21. → *FeatureStoreDegraded* → Policy: population defaults, mark degraded
22. → *ModelInferenceCompleted*
23. → *ChallengerInferenceCompleted* (shadow, never acted on)
24. → *AnomalyScoreProduced*
25. → *FeatureDriftDetected* → Policy: P3 alert
26. → *PredictionDriftDetected*
27. → *TrainingServingSkewDetected* → Policy: P2 alert
28. → *ModelInferenceFailed*

### Graph analysis (aggregate: FraudGraph)
29. `UpdateGraph` → *GraphNodeCreated*
30. → *GraphEdgeCreated*
31. → *GraphSignalsComputed*
32. → *GraphSignalCached*
33. → *RingDetected* → Policy: create case at Tier 3, freeze all member cards
34. → *MuleAccountIdentified*
35. → *AccountFarmingDetected*
36. → *GraphReconciliationDiscrepancy* → Policy: P2, targeted replay
37. → *GraphEdgesPruned*

### Risk scoring (aggregate: Decision)
38. `ComputeRiskScore` → *SignalsAggregated*
39. → *EngineUnavailableCompensated* (degradation margin applied)
40. → *ThresholdApplied*
41. → *RiskDecisionMade*
42. → *TransactionApproved*
43. → *StepUpAuthRequested*
44. → *StepUpAuthSucceeded*
45. → *StepUpAuthFailed* → Policy: decline and create case
46. → *TransactionDeclined*
47. → *TransactionRoutedToReview*
48. → *ExplanationGenerated*

### Case management (aggregate: FraudCase)
49. `CreateCase` → *CaseCreated*
50. → *CaseAssigned*
51. → *CasePrioritised*
52. → *CaseEscalated*
53. → *FraudConfirmed* → Policy: block card, initiate chargeback, label for training
54. → *FalsePositiveConfirmed* → Policy: whitelist pattern, label for training
55. → *CaseSlaBreached* → Policy: auto-escalate one tier
56. → *AlertsCorrelatedIntoIncident* → Policy: Target lesson — group before paging

### Notification, audit, profile
57. `SendNotification` → *NotificationQueued* / *NotificationDelivered* / *NotificationFailed*
58. → *AuditEntryAppended* / *AuditChainVerified* / *AuditChainBroken* → Policy: P1, freeze writes
59. → *CustomerProfileUpdated* / *ProfileRecomputed*

**Event 56 is the Target lesson encoded as a domain event.** Correlation happens *before*
paging, not after. The 2013 breach failed not because alerts were absent but because 1,797
terminals generated 1,797 independent alerts into a queue already receiving thousands daily.

## 2. Sagas

### 2.1 Transaction Processing Saga — choreography

```mermaid
sequenceDiagram
    participant GW as API Gateway
    participant TI as transaction-ingestion
    participant RE as rule-engine
    participant AD as anomaly-detection
    participant RS as risk-scoring
    participant K as Kafka
    participant GA as graph-analysis

    GW->>TI: SubmitTransaction
    TI->>TI: idempotency, validate, tokenise, enrich
    TI->>K: transactions.enriched (async)
    par parallel fan-out
        TI->>RE: Evaluate (25ms deadline)
        TI->>AD: Score (20ms deadline)
    end
    RE-->>TI: RuleEvaluationResult
    AD-->>TI: AnomalyScore
    TI->>RS: ComputeScore (15ms deadline)
    RS->>RS: read cached graph signal (Redis, 1ms)
    RS-->>TI: RiskDecision
    TI-->>GW: 200 decision
    K-->>GA: transactions.enriched
    GA->>GA: update graph, recompute signals
    GA->>K: fraud.graph.signals
    Note over GA: 1-5s behind the decision. Bounded and disclosed.
```

Choreography, not orchestration: the path is linear with no branching and no compensation
needed — nothing has been committed that would require undoing. An orchestrator here would
add a hop to the tightest latency budget in the platform for no benefit.

### 2.2 Fraud Investigation Saga — orchestration

Branching, human-in-the-loop, long-running (hours to days), with real compensations. An
orchestrator owns the state machine.

| Step | Service | Action | Compensation |
|---|---|---|---|
| 1 | case-management | Create case | Cancel case |
| 2 | **Core Banking System (external)** | Freeze card | **Unfreeze card** |
| 3 | notification | Alert cardholder | Send correction notification |
| 4 | case-management | Assign analyst | Return to queue |
| 5 | audit-compliance | Log initiation | None — append-only |
| 6 | case-management | Record disposition | — |
| 7a | Core Banking (confirmed fraud) | Permanent block + reissue | — |
| 7b | Core Banking (false positive) | Unfreeze | — |

**Step 2 is an external system, not a platform service.** The brief's §A1.5 orchestrates a
"Card Management Service" that appears in none of its bounded contexts (§A1.2). Card freeze is
an operation on the issuer's core banking system. Modelling it as an internal service would
imply the platform owns card state, which it does not — and the anti-corruption layer exists
precisely so that assumption cannot leak in. See [ERROR_DETECTION.md E4](ERROR_DETECTION.md).

**The compensation at step 2 is the one that matters.** If the saga fails after freezing a
card but before an analyst reviews it, an unfreeze must fire. Without it, a transient
downstream failure leaves a legitimate customer with a dead card and no explanation — the
most common way a fraud platform generates complaints. Compensation is idempotent and
retried with backoff; persistent failure raises P1, because a stuck freeze is a customer
harm, not a technical footnote.

### 2.3 Card Blocking Saga — orchestration

Confirmed fraud → block card (external) → issue replacement (external) → notify customer →
update profile → label transaction for model training. The final step closes the ML feedback
loop; without it, confirmed fraud never reaches the training set and the model's label lag
becomes permanent label absence.

## 3. CQRS read models

Write side: the decision pipeline, strongly consistent per transaction. Read side: Kafka
Streams materialised views, eventually consistent with a stated staleness bound.

| View | Source topics | Sink | Freshness | Serves |
|---|---|---|---|---|
| Real-time fraud statistics | `fraud.decisions` | TimescaleDB hypertable | 10 s | Dashboard KPI cards |
| Geographic heat map | `fraud.decisions` + `transactions.enriched` | TimescaleDB | 60 s | Heat map |
| Rule effectiveness | `fraud.rule.results` + `fraud.cases` | PostgreSQL | 5 min | Rule console, per-rule TP/FP |
| Model performance | `fraud.model.telemetry` + `fraud.cases` | PostgreSQL | Daily | Model dashboard |
| Case backlog | `fraud.cases` | PostgreSQL | 10 s | Ops workload view |

Rule effectiveness and model performance both join a fast stream against a slow one: case
dispositions arrive days after the decision. Implemented as a windowed join with a 90-day
retention on the decision side, which is a large state store and the reason this view is
materialised in PostgreSQL rather than held in Kafka Streams RocksDB state.

**Staleness is displayed in the UI.** A dashboard that silently shows 60-second-old data while
an incident is unfolding causes the operator to act on a stale picture. Every view renders its
own `as_of` timestamp.

## 4. Exactly-once, and where it does not apply

- **Producer:** `enable.idempotence=true`, `acks=all`, `max.in.flight=5`. Prevents duplicates
  from producer retries.
- **Consumer:** read-process-write inside a Kafka transaction where the sink is Kafka;
  idempotent upsert keyed on `transaction_id` where the sink is a database.
- **External calls (SMS, push, core banking) cannot be exactly-once.** No transactional
  boundary spans Kafka and an SMS gateway. Notification uses the outbox pattern with
  deduplication on `notification_id` and accepts at-least-once delivery — a cardholder
  receiving one duplicate SMS is an annoyance; a missing fraud alert is a loss. The asymmetry
  decides the design.
