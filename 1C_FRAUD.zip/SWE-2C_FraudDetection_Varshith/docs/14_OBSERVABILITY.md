# Observability: Logging, Tracing, Dashboards, Alerting

Alert rules: [`configs/prometheus/alert-rules.yml`](../configs/prometheus/alert-rules.yml).
Dashboards: [`configs/grafana/`](../configs/grafana/).

## 1. Structured logging

JSON only. Mandatory fields on every line:

```json
{"timestamp":"2026-03-15T19:42:11.482123Z","level":"INFO","service":"risk-scoring",
 "version":"1.4.2","trace_id":"4bf92f3577b34da6a3ce929d0e0e4736","span_id":"00f067aa0ba902b7",
 "transaction_id":"TXN-2026-03-15-0009182","event":"decision_made","decision":"REVIEW",
 "composite_score":742,"latency_ms":91,"jurisdiction":"IN"}
```

### PII masking is enforced at the serialiser, not by convention

A logging policy that asks developers not to log PANs fails the first time someone adds a
debug line under pressure. Instead:

- The log serialiser holds a **field denylist** (`pan`, `card_number`, `cvv`, `otp`,
  `phone`, `email`, `address`) and redacts by key name regardless of the value.
- A regex pass masks anything matching a 13–19 digit Luhn-valid sequence in free text, so a
  PAN embedded in an exception message is caught too.
- A **CI test asserts the redaction** by logging a synthetic PAN and failing the build if it
  appears in output. The control is tested, not assumed.

Retention: 30 days hot in Elasticsearch, 1 year in S3. `DEBUG` is never enabled in production
for services handling cardholder data — it is the most common source of accidental PII
exposure, and the exception process for enabling it requires a named approver and an expiry.

## 2. Distributed tracing

OpenTelemetry SDK, W3C `traceparent` propagation, Jaeger backend.

**Context propagates across Kafka, not just gRPC.** The `traceparent` is carried as a Kafka
header so a trace spans the synchronous decision and the asynchronous graph update that
follows it. Without this, the async half of the platform is invisible to tracing, and the
async half is where staleness bugs live.

Sampling:

| Traffic | Rate | Why |
|---|---|---|
| Baseline | 1% | Volume control at 2.4 M/day |
| Errors and 5xx | 100% | The interesting ones are never in a 1% sample |
| Latency > p99 | 100% | Tail-based sampling; the slow request is the one worth keeping |
| Declines and step-ups | 100% | Every customer-impacting decision is fully traceable |
| Step-up auth flows | 100% | Multi-hop, multi-second, easy to break |

Head-based sampling alone would discard exactly the traces that matter, so the collector runs
tail-based sampling for the error and latency classes.

Custom span attributes: `fraud.rule_hits`, `fraud.ml_score`, `fraud.graph_signal_age_seconds`,
`fraud.composite_score`, `fraud.decision`, `fraud.degraded_engines`.

## 3. Four Grafana dashboards

### 3.1 Transaction Processing
Throughput by channel; latency heatmap p50/p95/p99 against the 200 ms SLO line; per-hop
latency breakdown (gateway, ingest, enrichment, rules, ML, risk); error rate by service pair;
Kafka consumer lag per topic; **latency error-budget burn-down**.

### 3.2 Fraud Detection
Decision distribution (approve/step-up/review/decline); detection rate against mature labels
with the 90-day lag drawn on the axis so nobody reads it as current; **false positives per day
as an absolute count**, not a percentage; score distribution histogram with threshold overlays;
per-rule trigger and TP/FP rates; model PSI per feature; graph signal age distribution.

### 3.3 Case Management
Open cases by priority and age; SLA countdown per case; analyst workload and throughput;
mean time to disposition; disposition mix; backlog trend with a **projected clear time**.

The projection is the Paytm lesson (C1): a backlog is only dangerous when it grows faster
than it is worked, and that is visible in the derivative, not the level. A dashboard showing
"12,000 open cases" tells an operator less than one showing "growing 400/day, never clears".

### 3.4 Infrastructure
Pod CPU/memory against requests and limits; HPA replica counts; Kafka broker health and
under-replicated partitions; PostgreSQL connections, replication lag, slow queries; Redis hit
rate and evictions; Neo4j cluster state and query latency; **cost per transaction**.

## 4. Alerting

18 rules across P1–P4 in [`alert-rules.yml`](../configs/prometheus/alert-rules.yml).

**Alerting philosophy, from case study C1.** Target's SOC received thousands of alerts daily
and the one that mattered was indistinguishable from the rest. Three consequences:

1. **P1 pages. P2 goes to Slack. P3 is a daily digest. P4 is a weekly dashboard.** If
   everything pages, nothing does.
2. **Alerts correlate before they fire.** Fifty terminals in one store raising the same signal
   is one incident, not fifty alerts. Grouping is by `alertname`, `store_id` and a 5-minute
   window.
3. **Burn-rate alerting for SLOs, not threshold alerting.** A 14.4× burn pages immediately; a
   6× burn waits for business hours. A monthly error budget can be exhausted in four minutes,
   so an alert keyed to monthly exhaustion always arrives after the damage.

Every P1 and P2 has a runbook. An alert without a runbook wakes someone who then has to
reason from first principles at 3 a.m., which is when people are worst at it.

## 5. SLO measurement methodology

| SLO | Measured from | Excluded |
|---|---|---|
| Decision latency | Gateway access log, server-side | Client network time — not ours to control or fix |
| Availability | Synthetic probe every 10 s from 3 zones | Planned maintenance windows, announced 7 days ahead |
| Detection rate | Mature labels only (T-120 to T-90) | The recent window, where labels are incomplete |
| False positive rate | Analyst dispositions + non-disputed step-up approvals | Cases still open |

Detection and FPR are reported **monthly in arrears with the label-completeness figure
attached**. Any weekly detection-rate figure is a leading indicator, not a measurement, and
the dashboard labels it as such.
