# Master Architecture Document
## ShieldPay Real-Time Fraud Detection Platform

> **STRICTLY PRIVATE AND CONFIDENTIAL — NOT FOR CIRCULATION**
> © Zetheta Algorithms Private Limited. Produced against brief 463549C.

---

## Contents

1. [Executive summary](#1-executive-summary)
2. [Problem](#2-problem)
3. [Architecture](#3-architecture)
4. [Detection strategy](#4-detection-strategy)
5. [Resilience and security](#5-resilience-and-security)
6. [Observability and operations](#6-observability-and-operations)
7. [Deployment and disaster recovery](#7-deployment-and-disaster-recovery)
8. [Migration](#8-migration)
9. [Cost model and ROI](#9-cost-model-and-roi)
10. [Risks and limitations](#10-risks-and-limitations)
11. [Document index](#11-document-index)

---

## 1. Executive summary

ShieldPay's fraud losses rose from ₹12 crore to ₹53 crore per quarter while the false positive
rate went from 0.3% to 2.1%. The system got worse in both directions at once, which is the
signature of an architecture that has stopped fitting the problem rather than a tuning error.

The root cause is not the 500 hard-coded rules or the six-month-old model, though both are
real. It is the **15-minute batch scoring window**. Fraudsters reverse-engineered the cron
schedule and timed transactions to land immediately after a run, giving themselves up to
fifteen minutes of unscored spending. Batch scoring cannot inform an authorisation decision;
by the time it produces a number, the money has moved. Everything else in this design is
secondary to eliminating that window.

The proposal: **nine microservices** on an event-driven backbone, with three independent
detection engines — deterministic rules, ML inference and graph relationship analysis —
combined by a risk scoring service that produces an explainable decision inside a **p99 200 ms**
pipeline budget.

**What this document does not claim.** It does not claim a detection rate. The platform has
processed no transactions, and any detection or false-positive figure produced before it has
is a projection. Targets are stated with the methodology by which they will be measured and
the lag at which they become knowable.

---

## 2. Problem

| | Today | Target |
|---|---|---|
| Scoring | Batch, every 15 min | Inline, per transaction |
| Rules | 500 hard-coded in Java | Configuration, hot-reloadable |
| Model age | 6 months | 90-day maximum, drift-triggered |
| Ring detection | None | Graph analysis with 3 topology templates |
| Deploy cadence | Weekly, 4-hour window | Continuous, zero downtime |
| Rule change lead time | ~6 days | Minutes |
| Decision latency | Not measured | p50 50 ms, p99 200 ms |
| Explainability | None | Per-decision rationale, audit-retrievable |

Detail: [Monolith Analysis](02_MONOLITH_ANALYSIS.md).

---

## 3. Architecture

### 3.1 Services

Nine services, three shared datastores, one event backbone. Full table in
[Service Decomposition](04_SERVICE_DECOMPOSITION.md); C4 Levels 1–3 in
[`diagrams/`](../diagrams/).

The brief's range is 8–12. Nine is the low end, and deliberately so: each additional service
on the critical path costs ~2 ms per hop, one more failure mode and one more thing to page
about at 3 a.m. Customer Profile and Reference Data remain bounded contexts but are
implemented as Redis-backed libraries, because making them services buys independent
deployability of data that changes daily at a cost the latency budget cannot absorb.

### 3.2 Communication

gRPC on the synchronous critical path (binary serialisation, HTTP/2 multiplexing, typed
contracts, and — most importantly — **deadline propagation**, so a call that has already spent
80 ms upstream does not get a fresh budget downstream). Kafka for everything asynchronous, 12
topics keyed on `card_number_hash` so per-card ordering holds and windowed velocity counting
is correct.

REST at the edge only, transcoded at the gateway.
[Kafka topology](../configs/kafka/topics.yaml) · [OpenAPI](../api-specs/openapi.yaml) ·
[gRPC contracts](../api-specs/services.proto)

### 3.3 Data consistency

Strong consistency for the decision (deterministic, latest available data). Eventual for
analytics, profile updates and graph signals, with **stated staleness bounds** rather than
unbounded eventual consistency. Sagas replace distributed transactions: choreography for the
linear transaction path, orchestration for the branching investigation workflow.
[Detail](08_EVENT_DRIVEN_ARCHITECTURE.md).

### 3.4 The latency budget does not close

This is the single most consequential finding in the design, and it changes the architecture
rather than merely annotating it.

The brief offers a choice between synchronous graph updates (+5–15 ms, always current) and
asynchronous (1–5 s stale, lower latency), and asks for a quantitative justification. The
arithmetic removes the choice.

| Path | p99 |
|---|---|
| Gateway → ingestion → enrichment → engines → risk → response | **~84 ms** |
| Add synchronous graph (2 ms hop + 50 ms query) | **~136 ms** |
| §A1.4 gRPC critical-path budget | 100 ms |
| §A3.3 pipeline SLO | 200 ms |

At 136 ms the design breaches the gRPC budget outright and leaves 64 ms of headroom against
the pipeline SLO — which must absorb GC pauses, connection-pool waits, a Neo4j leader
re-election and traffic spikes. It will not hold.

Graph analysis therefore runs asynchronously, and the synchronous path reads a pre-computed
signal from Redis in 1 ms. The staleness window is 1–5 seconds, it is **disclosed in the
decision contract** as `graph_signal_age_seconds`, Risk Scoring applies a conservative margin
when the signal is missing or stale rather than reading absence as safety, and the single-hop
case is covered synchronously by rule DEV-002.

The brief's own §A2.5 decision SLA (< 100 ms) compounds this — it is tighter than the pipeline
SLO that produces it and carries no percentile. See [ERROR_DETECTION.md E3](ERROR_DETECTION.md)
and [SLA §4](05_SLA_SPECIFICATION.md).

---

## 4. Detection strategy

Three engines, deliberately independent — they never call each other, because an engine that
consults another correlates their failures.

| Engine | Detects | Needs labels? | Latency |
|---|---|---|---|
| **Rules** | Known patterns, policy, regulatory | No | 15 ms |
| **ML** | Statistical deviation at volume | Yes, 30–90 day lag | 10 ms |
| **Graph** | Rings via shared infrastructure | No | async |

### The label-lag argument

Confirmed fraud labels arrive by chargeback **30–90 days** after the transaction. A supervised
model therefore cannot detect a novel attack while it is running — the ShieldPay
synthetic-identity ring aged accounts for 90 days and busted out in one, and no retraining
cadence produces labels that do not yet exist.

**Consequence: ML carries volume, not novelty.** Rules and graph carry novel-attack detection
because they need no labels. Presenting ML as the primary defence against emerging fraud would
repeat the monolith's mistake in more fashionable form.

Composite scoring is configurable (weighted linear, maximum-of-signals, Bayesian), defaulting
to weighted linear with per-market, per-channel, per-product thresholds. Every decision carries
which rules fired with their matched values, the top five SHAP feature contributions, the graph
paths, and each engine's weighted contribution — assembled for a regulator, not for a log.

[Rules](09_RULE_ENGINE_DESIGN.md) · [ML](10_ML_ARCHITECTURE.md) · [Graph](11_GRAPH_ANALYSIS_DESIGN.md)

---

## 5. Resilience and security

Zero trust: Istio mTLS STRICT, deny-all default, every allowed path an explicit grant. PAN
never persists past the tokenisation component — PCI DSS Req 3 satisfied by the field's
absence from every schema rather than by a logging policy. Audit is hash-chained and
append-only at database, application and S3 Object Lock layers; the chain link is what makes
**deletion** detectable, which is the Wirecard failure mode.

Every service has a defined degraded mode. Rule engine down fails closed above ₹50,000 and
open below — bounding worst-case loss without declining the ordinary-value majority. Audit
down does **not** stop decisions, because making a compliance control into an availability
dependency guarantees someone adds a bypass during the first outage.

[Security & Compliance](12_SECURITY_AND_COMPLIANCE.md) · [Gateway](13_API_GATEWAY_RATE_LIMITING.md)
· [Fallback matrix](04_SERVICE_DECOMPOSITION.md#3-failure-domain-and-fallback-matrix)

---

## 6. Observability and operations

Three pillars with trace context propagating across **Kafka as well as gRPC**, so the async
half of the platform is not invisible. Tail-based sampling keeps 100% of errors, declines and
tail-latency traces; a 1% head sample would discard exactly the ones worth having.

Alerting follows the Target lesson (C1): alerts **correlate before they fire**, P1 pages while
P3 is a digest, and SLO alerting is burn-rate based — a monthly error budget can be exhausted
in four minutes, so an alert keyed to monthly exhaustion always arrives late.

[Observability](14_OBSERVABILITY.md) · [Alert rules](../configs/prometheus/alert-rules.yml)
· [Runbooks](runbooks/)

---

## 7. Deployment and disaster recovery

Differentiated per service: canary for ML (accuracy is only observable on live traffic),
blue-green for rules (a partial ruleset is worse than the old one), rolling with
`maxUnavailable: 0` for ingestion, expand-contract for schema.

Multi-region Mumbai primary / Singapore DR — with the constraint that **Indian cardholder data
replicates to an in-country secondary**, not to Singapore, because RBI data residency makes
the obvious topology a regulatory breach.

Cross-region RPO is stated honestly: synchronous replication over a 35 ms round trip would add
70 ms to every write and destroy the SLO, so replication is asynchronous and true regional
loss carries 10–30 seconds of exposure, recoverable from the Kafka event log.

[CI/CD & DR](15_CICD_AND_DR.md) · [Manifests](../samples/k8s/) · [Dockerfiles](../samples/docker/)

---

## 8. Migration

Strangler Fig, eight phases. Phases 1–3 (ingestion, rules in shadow, rules live) carry **zero
decision risk** by construction — the monolith still decides while the new path is proven
against it. The programme's credibility is spent at phase 4, inline ML scoring, which is where
it is actually needed. [Detail](02_MONOLITH_ANALYSIS.md#5-migration-sequence-strangler-fig).

---

## 9. Cost model and ROI

| | Monthly |
|---|---|
| New platform | ~$176,000 |
| Legacy monolith | ~$95,000 |
| **Delta** | **+$81,000 (~$1 M/year)** |

Cost per transaction ~$0.0024 (≈ ₹0.20), falling to ~$0.0016 at 5 M/day as fixed components
amortise.

**The honest CFO framing:** this platform costs about $1 M/year more to run. It is justified
only if it recovers a meaningful share of the ₹41 crore/quarter (~$19.6 M/year) increase in
fraud losses. Recovering 15% pays for it four times over. But **the detection improvement is a
projection, not a measurement**, and the figures above are derived from list prices against the
declared resource requests — not from a vendor quote and not from a bill.

[Detail](15_CICD_AND_DR.md#7-cost-model)

---

## 10. Risks and limitations

| Risk | Severity | Position |
|---|---|---|
| Detection rate unverifiable pre-launch | High | Shadow-mode phases 2–3 produce the first real measurement before any decision risk is taken |
| Friendly fraud | High, irreducible | No authorisation-time control can distinguish it. Handled post-hoc; excluded from detection targets |
| Graph defeated by disciplined tradecraft | Medium | A ring using per-identity infrastructure leaves no edges. The ceiling is set by the adversary, not the query design |
| Model evasion by boundary probing | Medium | Rate limiting raises cost; it does not remove the attack |
| Neo4j operational skill gap | Medium | ShieldPay has no in-house expertise. Hiring or managed service is a named dependency, not an assumption |
| Cross-region RPO 10–30 s | Medium | Physics. Bounded and reconstructable from Kafka |
| GDPR/RBI conflict for dual-jurisdiction cardholders | Medium | Legal determination. Architecture keeps identity separable so either answer is implementable |
| POS malware (Target class) | High, out of scope | This platform verifies financial accuracy, not data security. It should not be presented as covering it |
| Insider with deploy rights | Medium | Audit records it; it does not prevent it |
| Nine-service coupling via shared libraries | Low–Medium | A profile schema change requires coordinated release. Accepted trade against tail latency |

[Full threat model](12_SECURITY_AND_COMPLIANCE.md#7-threat-model-what-this-architecture-does-not-stop)

---

## 11. Document index

| Doc | Covers | Brief day |
|---|---|---|
| [01 Glossary](01_DOMAIN_GLOSSARY.md) | 62 terms | 1 |
| [02 Monolith Analysis](02_MONOLITH_ANALYSIS.md) | Capabilities, pain points, integrations, migration | 1 |
| [03 Bounded Contexts](03_BOUNDED_CONTEXTS.md) | Context map, relationship patterns | 2 |
| [04 Service Decomposition](04_SERVICE_DECOMPOSITION.md) | 9 services, fallback matrix | 2 |
| [05 SLA Specification](05_SLA_SPECIFICATION.md) | SLOs, error budgets, latency budget | 3 |
| [06 Persistence](06_PERSISTENCE_STRATEGY.md) | Polyglot stores, retention, GDPR/RBI | 3 |
| [08 Event-Driven Architecture](08_EVENT_DRIVEN_ARCHITECTURE.md) | 56 events, sagas, CQRS | 4, 6 |
| [09 Rule Engine](09_RULE_ENGINE_DESIGN.md) | Schema, lifecycle, simulation | 7 |
| [10 ML Architecture](10_ML_ARCHITECTURE.md) | Serving, features, drift, champion-challenger | 8 |
| [11 Graph Analysis](11_GRAPH_ANALYSIS_DESIGN.md) | Schema, 5 Cypher patterns, sync strategy | 9 |
| [12 Security & Compliance](12_SECURITY_AND_COMPLIANCE.md) | Mesh, PCI DSS mapping, threat model | 10 |
| [13 Gateway](13_API_GATEWAY_RATE_LIMITING.md) | Routing, 5 rate-limit tiers | 11 |
| [14 Observability](14_OBSERVABILITY.md) | Logging, tracing, 4 dashboards, alerting | 12, 13 |
| [15 CI/CD & DR](15_CICD_AND_DR.md) | Pipeline, topology, RPO/RTO, chaos, cost | 14 |
| [ERROR_DETECTION](ERROR_DETECTION.md) | 5 planted errors + 6 further inconsistencies | 15 |
| [AI_USAGE](AI_USAGE.md) | §E5 disclosure | — |
| [SELF_ASSESSMENT](SELF_ASSESSMENT.md) | Rubric review and gaps | 15 |
