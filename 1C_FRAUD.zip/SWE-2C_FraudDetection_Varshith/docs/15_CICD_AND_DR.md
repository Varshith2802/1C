# CI/CD, Deployment Topology and Disaster Recovery

## 1. Pipeline

```
source → build → unit+contract test → SAST + dependency scan → image build + sign
  → image scan (Trivy) → integration test → stage deploy → smoke
  → canary/blue-green/rolling (per service) → production → post-deploy verification
```

| Gate | Tool | Blocks on |
|---|---|---|
| Unit + contract | JUnit / pytest, Pact | Coverage < 80%, any contract break |
| SAST | Semgrep, SpotBugs | HIGH or CRITICAL |
| Dependency | Grype, `pip-audit` | CRITICAL CVE with a fix available |
| Image scan | Trivy | HIGH/CRITICAL in OS or app layers |
| Signing | cosign + SBOM (CycloneDX) | Unsigned image is refused at admission |
| Integration | testcontainers | Any failure |
| Policy | OPA Gatekeeper | Missing resource requests, `runAsRoot`, `latest` tag |

**Contract testing is the gate that matters most in a nine-service platform.** Nothing else
catches a producer changing a Protobuf field in a way that breaks a consumer, and by the time
an integration environment finds it, both teams have moved on.

## 2. Deployment strategy per service

| Service | Strategy | Why this one |
|---|---|---|
| **anomaly-detection** | Canary 5→25→50→100% | Model accuracy is only observable on live traffic. 5% of 2.4 M/day is 120,000 transactions — statistically significant within hours |
| **rule-engine** | Blue-green | Rules must apply as a complete set. A partial ruleset mid-rollout means some transactions are scored by ruleset N and some by N+1, and no one can say which. Atomic switch or nothing |
| **transaction-ingestion** | Rolling, `maxUnavailable: 0` | Zero message loss requires old pods to keep serving until new pods are ready |
| **Database schema** | Expand-contract | Expand → migrate code → contract. Never a breaking change in one step |
| **case-management, notification** | Rolling | Non-critical path; standard rolling is sufficient |

### Zero message loss during rolling updates — the actual mechanism

The brief's "Zero-Downtime Deployer" badge asks for provable zero loss. It rests on four
things together, and removing any one breaks it:

1. `maxUnavailable: 0` — capacity never drops below current.
2. `preStop: sleep 15` — the pod keeps serving during the window between endpoint removal and
   SIGTERM. **Without this, in-flight requests are lost**, because endpoint removal and
   SIGTERM are concurrent, not ordered. This is the single most commonly missed step.
3. `terminationGracePeriodSeconds: 45` > preStop (15 s) + worst-case in-flight (25 ms) +
   Kafka offset commit.
4. Kafka consumers commit offsets **after** processing, so a killed consumer replays rather
   than skips. Processing is idempotent on `transaction_id`, so replay is safe.

The proof is at-least-once delivery plus idempotent processing, not zero-duplicate delivery.
Claiming exactly-once across a pod restart would be false.

## 3. Multi-region topology

| | Primary | DR |
|---|---|---|
| Region | Mumbai (ap-south-1) | Singapore (ap-southeast-1) |
| Kubernetes | 3 AZ, full platform | 3 AZ, warm standby at 30% capacity |
| PostgreSQL | Synchronous replication within region | Asynchronous cross-region |
| Kafka | 3 brokers per AZ, RF=3 | MirrorMaker 2 with offset translation |
| Redis | Cluster mode, 3 shards | Replicated; feature store rebuildable from source |
| Neo4j | Causal cluster, 3 core + 2 replica | Async replica; **fully rebuildable from Kafka** |
| DNS | Route 53 health-checked failover | 60 s TTL |

**Data residency is a constraint, not a preference.** RBI requires payment data of Indian
customers to be stored in India. The Singapore region therefore holds **only** non-Indian
market data in steady state; Indian data replicates to an in-country secondary (Hyderabad)
instead. A DR plan that fails over Indian cardholder data to Singapore is a regulatory breach
dressed as resilience, and it is an easy mistake to make when the topology is drawn without
a lawyer in the room.

## 4. RPO / RTO

| Tier | Services | RPO | RTO | Mechanism |
|---|---|---|---|---|
| 1 | ingestion, rule-engine, risk-scoring | < 1 min | < 5 min | Sync replication in region, pre-provisioned standby, automated failover |
| 2 | case-management, notification, analytics | < 15 min | < 30 min | Async replication, semi-automated |
| 3 | reporting, admin | < 1 h | < 4 h | Nightly snapshot |

**Where the stated RPO is optimistic, and why it is stated anyway.** Tier 1 RPO < 1 minute is
achievable within a region using synchronous replication. **Cross-region it is not**, because
synchronous replication over the ~35 ms Mumbai–Singapore round trip would add 70 ms to every
write and destroy the latency SLO. Cross-region replication is asynchronous, so a true
regional loss carries an RPO of roughly **10–30 seconds of replication lag**, not under 1
minute of guaranteed data.

Mitigation: Kafka MirrorMaker 2 replicates the event log, so transactions accepted but not
yet replicated to the database are recoverable from the event stream. The gap is real but
bounded and reconstructable. A DR plan that claims sub-minute cross-region RPO without saying
how has not thought about the speed of light.

## 5. Failover runbook

| Phase | Content |
|---|---|
| **Detection** | Route 53 health check fails 3× in 90 s, **or** decision success rate < 50% for 2 min, **or** manual declaration |
| **Decision** | VP Engineering or on-call incident commander authorises. **Never automatic.** An automatic cross-region failover on a transient network partition causes split-brain, and split-brain in a payments platform means two regions independently approving against the same balance |
| **Execution** | 1. Scale DR to 100% (pre-provisioned, ~3 min) · 2. Promote PostgreSQL replica · 3. Stop MirrorMaker inbound; verify offset translation · 4. Switch Route 53 · 5. Verify mesh identity in DR |
| **Verification** | Synthetic transaction end-to-end; decision latency within SLO; audit chain verifies; Kafka lag draining; graph rebuild progress |
| **Rollback** | Reverse replication, wait for lag → 0, verify, switch DNS back during a low-traffic window |

**Known gap, stated rather than hidden:** the Neo4j graph in DR is asynchronously replicated
and may be minutes behind. After failover, graph signals are stale until rebuild completes
(estimated ~6 h for the full 180-day window — an estimate, not a measurement). Risk Scoring
applies the conservative margin for absent graph signals during that period, so detection
degrades gracefully rather than silently. This is a real reduction in capability during DR
and the Board should know it.

## 6. Chaos experiments

| # | Experiment | Expected behaviour | Detecting signal |
|---|---|---|---|
| 1 | Kill 50% of rule-engine pods | PDB holds ≥ 4; HPA replaces; latency rises within SLO | `kube_deployment_status_replicas_available`, p99 latency |
| 2 | Partition anomaly-detection from feature store | Population defaults; `degraded_features=true`; decisions continue | `fraud_feature_store_defaults_total` → P1 |
| 3 | Inject 200 ms into the enrichment provider | Circuit opens; transactions proceed with `device_signal=UNAVAILABLE` | `fraud_enrichment_circuit_open_total` |
| 4 | Kill the Kafka partition leader | Leader election < 10 s; producers retry; **zero message loss** | Under-replicated partitions, producer error rate |
| 5 | Force PostgreSQL failover | Replica promotes; connection pools reconnect; < 30 s write outage | `pg_replication_lag`, connection error rate |
| 6 | Stop Neo4j entirely | Graph signals absent; conservative margin applied; decisions continue | `fraud_graph_signal_age_seconds` → P2 |
| 7 | Saturate CPU on 3 nodes | HPA scales; topology spread rebalances | Throttling metrics, HPA events |

Experiment 4 is the one most likely to fail the first time it is run. Zero message loss during
leader election requires `acks=all`, `min.insync.replicas=2`, `enable.idempotence=true` **and**
`unclean.leader.election.enable=false` simultaneously. Any one missing, and the experiment
silently loses messages — silently being the operative word, because a lost authorisation
event looks exactly like a transaction that never arrived.

## 7. Cost model

Estimates at 2.4 M transactions/day, Mumbai primary plus Singapore DR. **Derived from
published list prices against the resource requests in `samples/k8s/`, not from a quote and
not from a measured bill.** Treat as an order-of-magnitude figure for the CFO discussion.

| Component | Monthly (USD) |
|---|---|
| Kubernetes compute, primary (~60 nodes) | 42,000 |
| Kubernetes compute, DR warm 30% | 13,000 |
| PostgreSQL managed, HA + replicas | 18,000 |
| Kafka managed, 9 brokers + MirrorMaker | 22,000 |
| Redis cluster | 8,000 |
| Neo4j Enterprise (licence + compute) | 24,000 |
| TimescaleDB + Elasticsearch | 11,000 |
| S3, Object Lock, archive | 3,500 |
| Network egress + cross-region replication | 9,000 |
| Observability (Prometheus, Grafana, Jaeger, logs) | 7,500 |
| Third-party enrichment (device + geo, per-call) | 18,000 |
| **Total** | **~176,000** |

- **Cost per transaction: ~$0.0024** (≈ ₹0.20) at 72 M transactions/month.
- Legacy monolith run cost: ~$95,000/month (bare metal, Oracle licensing, ops staff).
- **Delta: ~$81,000/month higher.**

The honest framing for the CFO: this platform costs roughly **$1 M/year more** to run. It is
justified only if it recovers a meaningful share of the ₹41 crore/quarter (~$19.6 M/year)
increase in fraud losses. Recovering even 15% pays for the platform four times over — but the
detection improvement is a **projection, not a measurement**, and the only honest way to
present it is with that caveat attached. Scaling is sub-linear: compute grows with peak TPS,
while Neo4j, Kafka and observability are largely fixed, so at 5 M transactions/day the
per-transaction cost falls to roughly $0.0016.
