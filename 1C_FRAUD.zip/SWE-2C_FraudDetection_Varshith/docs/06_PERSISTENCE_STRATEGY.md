# Polyglot Persistence

## 1. Store per workload

| Store | Used by | Why this one | What it costs |
|---|---|---|---|
| **PostgreSQL 16** | ingestion, rule-engine, risk-scoring, case-management, audit | ACID for financial records; declarative partitioning for retention; mature operational tooling | Vertical write ceiling; partition maintenance is real work |
| **Redis 7** | feature store, profile, reference data, rate limits, graph signal cache | Sub-ms reads; atomic counters for distributed rate limiting | Volatile — every consumer needs a defined cold-cache path |
| **Neo4j 5** | graph-analysis | Index-free adjacency makes multi-hop traversal independent of total graph size | Cluster ops expertise; write throughput ceiling drives async updates |
| **TimescaleDB** | analytics-projection | Time-partitioned hypertables, continuous aggregates | Another Postgres flavour to operate |
| **Elasticsearch** | log search, merchant fuzzy match | Inverted index | Heavy; not on any decision path |
| **S3 + Object Lock** | audit archive, model artefacts | WORM satisfies immutability at the storage layer, not just the application layer | Retrieval latency |

## 2. Why not one database

The monolith's 3-second analytical query was caused by OLAP competing with OLTP on one Oracle
instance (see [Monolith Analysis §2.4](02_MONOLITH_ANALYSIS.md)). Splitting by workload is the
fix. But polyglot persistence is not free and pretending otherwise is dishonest:

- Six datastores means six backup regimes, six upgrade paths, six sets of failure modes and
  six things a 3 a.m. page can be about.
- Cross-store consistency becomes an application concern — no join, no foreign key, no
  transaction spans them.
- Team skill requirements go up sharply. Neo4j cluster operations in particular is a
  specialist skill ShieldPay does not currently have, and the hiring plan has to say so.

The alternative — PostgreSQL for everything, including a recursive-CTE graph — is genuinely
viable up to perhaps 10 M nodes. It was rejected because multi-hop ring queries at
authorisation latency are exactly where relational traversal falls over, and ring detection
is the capability gap that caused the crisis. That is a specific reason, not a general
preference for specialist stores.

## 3. Retention and the GDPR/RBI conflict

| Data | Hot | Warm | Cold | Basis |
|---|---|---|---|---|
| Raw transactions | 90 d Postgres | 2 y compressed partitions | 7 y S3 | RBI record retention |
| Decisions + explanations | 90 d | 2 y | 7 y | Regulatory examination |
| Audit chain | 1 y | 7 y | Indefinite S3 Object Lock | RBI 7 y; PCI DSS ≥ 1 y detailed |
| Graph edges | 180 d active | — | Archived | §A2.4 pruning |
| Feature store | TTL 24 h – 90 d | — | — | Recomputable |
| PII (name, address, phone) | 90 d | pseudonymised | pseudonymised | GDPR |

**The conflict is real and cannot be resolved by policy.** GDPR Art. 17 gives an EU cardholder
a right to erasure; RBI requires 7-year retention of the same records. Both cannot be fully
satisfied for a single record.

The resolution is **jurisdiction-scoped pseudonymisation**, not deletion:

1. Every record carries a `jurisdiction` derived from the issuing entity, not the cardholder's
   current location — this matters, because location changes and the applicable regime does not.
2. On an erasure request from an EU cardholder, direct identifiers are replaced with an opaque
   `subject_key`; the transaction record, decision and audit chain survive intact.
3. The identifier mapping is held in a separate encrypted vault whose key is destroyed at the
   end of the retention period, making re-identification cryptographically infeasible while the
   financial record remains complete and the audit hash chain stays verifiable.
4. Indian-jurisdiction records are retained in full; RBI's requirement is a legal obligation
   under Art. 6(1)(c) and Art. 17(3)(b), which is a lawful basis for refusing erasure.

**What this does not solve:** a cardholder with an EU-issued card transacting in India sits
under both regimes simultaneously, and the pseudonymisation above is a defensible position,
not a settled one. That determination is legal, not architectural. The architecture's job is
to make either answer implementable, which it does by keeping identity separable from the
financial record from day one. Flagged for Legal in the Board deck.
