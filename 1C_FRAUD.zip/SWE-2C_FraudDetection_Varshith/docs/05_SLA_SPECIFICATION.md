# Service-Level Agreements

## 1. Platform SLOs

| Metric | Target | Measured how |
|---|---|---|
| Decision latency (POST /transactions) | p50 < 50 ms, p95 < 150 ms, **p99 < 200 ms** | API-gateway access log, server-side |
| Detection rate | > 95% of confirmed fraud flagged | Monthly reconciliation against chargeback labels, 90-day lag |
| False positive rate | < 0.5% of legitimate transactions | Analyst dispositions + non-disputed step-up approvals |
| Availability, decision path | 99.99% (≈ 4.4 min/month) | Synthetic probe every 10 s from three zones |
| Availability, case & dashboards | 99.9% (≈ 43 min/month) | Same |
| Kafka consumer lag | < 1,000 msg/partition steady state | `kafka_consumergroup_lag` |
| Error rate per service | < 0.1% 5xx | Envoy metrics per service pair |

**Detection and false-positive rates are not verifiable at design time.** They depend on data
the platform has not yet seen. They are stated as targets with a measurement methodology and
a review cadence, and any claim that a design "achieves 95% detection" before it has processed
a transaction should be read as marketing.

## 2. Per-service SLA

| Service | p50 | p95 | p99 | Availability | Throughput | Depends on |
|---|---|---|---|---|---|---|
| transaction-ingestion | 8 ms | 20 ms | 35 ms | 99.99% | 500 TPS | Enrichment providers (circuit-broken) |
| rule-engine | 4 ms | 9 ms | 15 ms | 99.99% | 500 TPS | Redis (profile/reference) p99 1 ms |
| anomaly-detection | 3 ms | 7 ms | 10 ms | 99.95% | 500 TPS | Feature store p99 1 ms |
| graph-analysis | 12 ms | 30 ms | 50 ms | 99.9% | 500 TPS | Neo4j read replica |
| risk-scoring | 2 ms | 4 ms | 8 ms | 99.99% | 500 TPS | All three engines |
| case-management | 40 ms | 120 ms | 250 ms | 99.9% | 50 TPS | PostgreSQL |
| notification | async | — | 5 s to dispatch | 99.9% | 200/s | SMS/push providers |
| audit-compliance | async | — | 2 s to durable | 99.99% | 2,000/s | PostgreSQL + S3 |
| analytics-projection | async | — | 60 s freshness | 99.5% | Kafka-bound | Kafka |

## 3. Error budget policy

| Tier | SLO | Monthly budget | On exhaustion |
|---|---|---|---|
| 1 — decision path | 99.99% | 4.4 min | Feature deploys frozen; reliability work only; CTO sign-off to unfreeze |
| 2 — case, notification | 99.9% | 43 min | Deploys continue; reliability item mandatory in next sprint |
| 3 — analytics, admin | 99.5% | 3.6 h | Tracked, no automatic action |

Burn-rate alerting, not simple threshold alerting: a 14.4× burn over 1 hour pages immediately;
a 6× burn over 6 hours pages during business hours. A month's budget can be spent in 4 minutes,
so an alert that fires on monthly exhaustion always fires too late.

## 4. The latency budget

### 4.1 Synchronous critical path

| Hop | Component | p99 budget | Basis |
|---|---|---|---|
| 1 | Gateway → ingestion (incl. mTLS, routing) | 5 ms | Envoy p99 overhead, measured at comparable scale |
| 2 | Ingestion: validate, normalise, enrich (cache hit) | 35 ms | 30 ms enrichment call + 5 ms local |
| 3 | Ingestion → rule-engine gRPC | 2 ms | Same-cluster hop, Protobuf |
| 4 | Rule engine evaluation | 15 ms | 500 compiled rules, short-circuit, in-memory windows |
| 5 | Ingestion → anomaly-detection gRPC | 2 ms | Same |
| 6 | Model inference + SHAP | 10 ms | ONNX GBDT, ~200 features, warm |
| 7 | Rule + anomaly → risk-scoring gRPC | 2 ms | Same |
| 8 | Score aggregation + explanation assembly | 8 ms | |
| 9 | Response to gateway | 5 ms | |
| | **Total (steps 4–6 in parallel)** | **~84 ms** | |

Steps 4 and 6 run concurrently, so the engine stage costs max(15, 10) = 15 ms, not 25 ms.

### 4.2 Where the budget actually goes

The dominant term is **enrichment at 30 ms** — a third-party device-fingerprinting call. It
is larger than every internal component combined. Two consequences the design takes seriously:

- Enrichment is behind a circuit breaker with a 40 ms deadline. On timeout the transaction
  proceeds with `device_signal=UNAVAILABLE` and the model uses a population default.
- Caching by device fingerprint for 24 h takes the cache-hit path to ~5 ms. Cold-path p99
  assumes a miss because p99 *is* the miss.

### 4.3 Graph analysis is not in the table

Adding graph-analysis synchronously adds 2 ms (hop) + 50 ms (query p99) = **52 ms**, taking
the path to ~136 ms p99. That exceeds the 100 ms gRPC critical-path budget of §A1.4 and
approaches the 200 ms pipeline SLO with no headroom for GC pauses, connection-pool waits or
a Neo4j leader re-election.

Graph analysis therefore runs **asynchronously**, and the synchronous path reads a
pre-computed graph risk signal from Redis (p99 1 ms) written by the async consumer. The full
argument, including what this costs in detection terms and how the staleness window is
bounded, is in [Master Architecture §3.4](00_MASTER_ARCHITECTURE.md#34-the-latency-budget-does-not-close)
and [Graph Analysis Design §4](11_GRAPH_ANALYSIS_DESIGN.md).

### 4.4 The decision-action SLA in the brief does not fit this budget

§A2.5 assigns auto-approve and auto-decline an SLA of **< 100 ms**. The pipeline SLO in §A3.3
is **p99 < 200 ms**. A decision cannot be delivered in under 100 ms if the pipeline that
produces it is permitted 200 ms, and §A2.5 states no percentile, so the two are not even
expressed in comparable units.

This platform resolves it as:

| Action | Stated SLA | Interpretation used here |
|---|---|---|
| Auto-approve | < 100 ms | p50 < 50 ms, p99 < 200 ms — the pipeline SLO governs |
| Auto-decline | < 100 ms | Same |
| Step-up auth | < 5 s | Decision p99 200 ms + challenge round trip |
| Manual review | < 4 h | Case SLA, not a latency SLA |

See [ERROR_DETECTION.md E3](ERROR_DETECTION.md).
