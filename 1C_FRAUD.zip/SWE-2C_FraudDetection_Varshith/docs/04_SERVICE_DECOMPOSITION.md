# Service Decomposition

## 1. Service table

Nine services. The brief asks for 8–12; the reasoning for the low end is in §2.

| # | Service | Responsibility | Language / framework | Datastore | Team (3–5 eng) | Scaling trigger |
|---|---|---|---|---|---|---|
| 1 | **transaction-ingestion** | Accept from all channels, normalise, enrich, publish | Java 21 / Spring Boot 3 | PostgreSQL 16 (partitioned daily) | Payments Platform | Request rate |
| 2 | **rule-engine** | Evaluate configured rules, emit per-rule results | Java 21 / Spring Boot 3 | PostgreSQL (rules) + in-memory compiled cache | Detection Rules | Request rate |
| 3 | **anomaly-detection** | ML inference, feature retrieval, SHAP attribution | Python 3.12 / FastAPI + ONNX Runtime | Redis (feature store), S3 (models) | Data Science Eng | Request rate, GPU util |
| 4 | **graph-analysis** | Relationship signals, ring detection | Java 21 / Spring Boot 3 | Neo4j 5 (causal cluster) | Graph & Networks | Query concurrency |
| 5 | **risk-scoring** | Aggregate signals, apply thresholds, emit explainable decision | Java 21 / Spring Boot 3 | PostgreSQL (decisions) | Decision Engine | Request rate |
| 6 | **case-management** | Investigation workflow, assignment, disposition | Java 21 / Spring Boot 3 | PostgreSQL | Fraud Ops Tooling | Analyst count |
| 7 | **notification** | Multi-channel, localised alerting | Go 1.23 | PostgreSQL (outbox) + Redis | Comms Platform | Alert volume |
| 8 | **audit-compliance** | Hash-chained audit, regulatory reporting | Java 21 / Spring Boot 3 | PostgreSQL (append-only) + S3 Object Lock | Compliance Eng | Event rate |
| 9 | **analytics-projection** | CQRS materialised views | Java 21 / Kafka Streams | TimescaleDB + Elasticsearch | Analytics Platform | Kafka lag |

Two non-service components, deployed as libraries with a shared batch writer:
**customer-profile** (Redis + daily Spark job) and **reference-data** (Redis + feed ingesters).

### Polyglot choices, justified rather than assumed

Language diversity is a cost — three toolchains, three sets of CVE patches, three on-call
runbooks. Each departure from Java earns its place:

- **Python for anomaly-detection**: the model artefacts, ONNX Runtime bindings and SHAP are
  native to it. Re-implementing SHAP in Java to preserve monoculture would be a worse trade.
- **Go for notification**: tens of thousands of concurrent outbound HTTP/SMS calls with
  trivial business logic. Goroutines fit; a JVM thread pool sized for this is wasteful.
- **Java everywhere else**: ShieldPay has 12 years of Java staff. Migrating the domain logic
  *and* the language at once doubles the risk for no detection benefit.

## 2. Why nine and not twelve

Service count is not a quality metric. Each additional service on the critical path costs:

- **~2 ms p99** per network hop (mTLS handshake amortised, serialisation, queueing)
- one more failure mode in the decision path
- one more deployment, dashboard, alert route and on-call runbook

The critical path budget is 100 ms p99 (§A1.4) and, as [Master Architecture §3.4](00_MASTER_ARCHITECTURE.md#34-the-latency-budget-does-not-close)
shows, it is already tight. Splitting enrichment out of ingestion, or profile and reference
data into services, would buy independent deployability for data that changes daily at a cost
of 6 ms on every one of 2.4 M daily transactions.

**The honest counter-argument**: nine services with two shared libraries means the libraries
are a coupling point, and a profile-schema change becomes a coordinated release. A reviewer
who values deployment independence over tail latency would reasonably choose eleven services.
The trade is defensible either way; what is not defensible is choosing twelve because the
brief's range tops out there.

## 3. Failure domain and fallback matrix

Directly from the Netflix lesson (C3): every service needs a defined degraded mode, or the
first dependency outage becomes an availability outage.

| Service down | Decision path behaviour | Detection impact | Alert |
|---|---|---|---|
| rule-engine | **Fail closed above ₹50,000**, rule score = 0 below | Severe — known patterns unscreened | P1 |
| anomaly-detection | Proceed on rules + graph; approve threshold 200 → 120 | Moderate — novel patterns missed | P1 |
| graph-analysis | Proceed; add +40 fixed risk margin | Low — ring detection lost | P2 |
| feature store (Redis) | Population-average features, flag `degraded_features` | Moderate — model accuracy drops materially | P1 |
| neo4j | As graph-analysis down | Low | P2 |
| case-management | Alerts queue in Kafka; no decision impact | None at decision time | P2 |
| notification | Outbox retains; replay on recovery | None | P2 |
| audit-compliance | **Decisions continue**; events buffer in Kafka (infinite retention) | None | P1 (regulatory) |
| Kafka (full outage) | Synchronous path survives; all async consumers stall | Graph staleness grows | P1 |

Two of these deserve argument:

**Rule engine fails closed above ₹50,000, open below.** A uniform fail-closed declines ~28 TPS
of legitimate traffic and generates a customer-service incident within minutes. A uniform
fail-open leaves every transaction unscreened by the one engine that catches known patterns.
The split bounds worst-case loss during an outage while keeping the ordinary-value majority
flowing. The threshold is a business input, not an engineering one, and is configurable per
market.

**Audit down does not stop decisions.** This looks wrong for a compliance system and is
deliberate. Audit events are published to Kafka with infinite retention *before* the audit
service consumes them, so the durable record exists even when the service does not. Blocking
authorisation on the audit service would make a compliance control into an availability
dependency — and the predictable consequence is that someone adds a bypass flag during the
first outage, which is far worse than a few minutes of delayed indexing.
