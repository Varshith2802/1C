# Legacy Monolith Analysis

## 1. What exists today

| Dimension | Current state | Consequence |
|---|---|---|
| Codebase | 1.2 MLOC Java, first written 2012 | Change cost is superlinear; no module can be reasoned about alone |
| Rules | 500+ hard-coded in Java `switch` statements | A threshold change is a code change, a release and a 4-hour window |
| Data | Single Oracle 19c, 45 TB, 3 s analytical queries | Analytics contends with authorisation on the same instance |
| ML | Logistic regression scored by cron every 15 min, model 6 months old | See §2.3 — this is the exploited gap |
| Deployment | WAR files on Tomcat 8.5, manual, Saturday 4-hour window | Response time to a live attack is measured in days |
| Resilience | No read replicas, no cross-region replication | The Oracle instance is an unmitigated single point of failure |
| Observability | Application logs on local disk | No correlation ID, so no end-to-end latency attribution |

**Arithmetic worth stating.** 2.4 M transactions/day is ~28 TPS average. Indian card and UPI
traffic peaks at roughly 4–6× the daily mean in the 19:00–22:00 IST window and far higher on
festival days, so the design point is ~170 TPS sustained peak and a 500 TPS burst ceiling.
Any capacity claim in this repository is against 500 TPS, not 28.

## 2. Pain points, ranked by what they cost

### 2.1 Batch scoring is the root cause, not a symptom

The 15-minute cron is the single defect that produced the crisis. Three separate failures
follow from it:

1. **An exploitable window.** Fraudsters timed transactions to land immediately after a batch
   run, giving them ~15 minutes of unscored spending — 10–20 transactions each.
2. **No feedback loop.** A model scored in batch cannot inform the authorisation decision, so
   its output is an alert, not a control. The money has already moved.
3. **Stale features.** Velocity features computed at batch time are up to 15 minutes old,
   which is precisely the interval an enumeration attack operates in.

Moving to per-transaction inline scoring is the primary architectural requirement. Everything
else is secondary.

### 2.2 Hard-coded rules make the system unable to respond

When a novel attack appears, the correct response is a new rule within the hour. Today it is
a Java change, a build, a QA cycle and the next Saturday window — a best case of six days. The
340% surge ran for a full quarter partly because the system could not be adjusted while it was
happening.

### 2.3 The model was six months old against an adversary that adapts weekly

A logistic regression trained on data from H1 could not have seen AI-generated synthetic
identities, because they did not exist in the training window. **No retraining cadence fixes
this**, and it is worth being blunt: supervised learning is structurally late to novel attacks
because its labels come from chargebacks that arrive 30–90 days after the fact. A synthetic-
identity ring that ages accounts for 90 days and busts out in one day is invisible to a
supervised model for the entire operation and for months afterwards. This is the reasoning
behind putting rules and graph analysis — not ML — on the novel-attack path.

### 2.4 One database, four workloads

Authorisation (OLTP, millisecond), case management (OLTP, human-speed), analytics (OLAP,
seconds) and audit (append-only, never deleted) share one Oracle instance. The 3-second
analytical query is not slow because Oracle is slow; it is slow because it competes with the
authorisation path. Polyglot persistence is not a fashion here, it is workload separation.

### 2.5 No graph capability at all

Synthetic-identity rings are detectable almost exclusively through shared infrastructure —
the same device, address, IP subnet or phone across hundreds of "unrelated" accounts. A
row-oriented relational schema can express that query; it cannot answer it at authorisation
latency. This capability does not exist today and is the largest detection gap.

## 3. Business capability map

| Monolith module | Business capability | Destination service |
|---|---|---|
| `TxnReceiver.java`, channel adapters | Transaction acceptance and normalisation | Transaction Ingestion |
| Device/geo enrichment calls | Transaction enrichment | Transaction Ingestion (enrichment component) |
| `FraudRules*.java` switch blocks | Fraud rule evaluation | Rule Engine |
| `BatchScorer` cron | Anomaly scoring | Anomaly Detection |
| *(absent)* | Relationship analysis | Graph Analysis (new capability) |
| `DecisionEngine.java` | Risk aggregation and decisioning | Risk Scoring |
| `CaseWorkflow.java`, analyst JSPs | Fraud investigation | Case Management |
| `AlertSender.java` | Customer and internal notification | Notification |
| `AuditWriter.java` | Audit and regulatory reporting | Audit & Compliance |
| `CustomerStats` tables | Behavioural profiling | Customer Profile |
| `RefData` tables (BIN, MCC, watchlists) | Reference data | Reference Data |

## 4. External integrations to preserve

| System | Direction | Protocol | Migration note |
|---|---|---|---|
| Visa / Mastercard / RuPay | Bidirectional | ISO 8583 over TCP, persistent sessions | Highest-risk integration. ISO 8583 is stateful and session-oriented; the adapter must own connection lifecycle and cannot be a stateless pod that restarts freely |
| Core Banking System | Outbound query | Mainframe MQ | Authoritative balance and account status. The Cosmos Bank lesson (C2) is that this must be verified, not assumed |
| Customer mobile app | Outbound push, inbound step-up | HTTPS + APNs/FCM | Step-up response must return inside the 5 s SLA |
| ThreatMetrix (device) | Outbound | HTTPS REST | Third-party on the critical path — needs a circuit breaker and a defined degraded mode |
| MaxMind (geo) | Outbound | Local DB + HTTPS | Prefer the local database to keep it off the network path |
| RBI / FIU-IND reporting | Outbound batch | SFTP | Filing obligations; correctness beats latency |
| Legacy Oracle monolith | Bidirectional | JDBC via anti-corruption layer | Temporary, removed at the end of migration |

## 5. Migration sequence (Strangler Fig)

Ordered by risk-adjusted value, not by ease:

1. **Transaction Ingestion + Kafka backbone, shadow mode.** Events are published; the monolith
   still decides. Zero decision risk, and it produces the traffic sample every later phase
   needs for validation.
2. **Rule Engine, shadow.** The 500 hard-coded rules are extracted to configuration and run in
   parallel. Any divergence from the monolith's output is a bug in the extraction — this is
   the phase that proves the migration is faithful, and it is the phase most often skipped.
3. **Rule Engine, live.** Cut over once divergence is zero across a full week including a
   festival peak.
4. **Anomaly Detection inline.** Closes the exploited 15-minute window. The highest-value step.
5. **Graph Analysis.** New capability; asynchronous from day one (see Master Architecture §3.4).
6. **Risk Scoring.** Takes over composite decisioning from the monolith.
7. **Case Management, Notification, Customer Profile, Reference Data.**
8. **Decommission.** Oracle retained read-only for the 7-year retention window.

Phases 1–3 deliberately carry no decision risk. The programme's credibility is spent in phase
4, where it is actually needed.
