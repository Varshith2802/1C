# Rule Engine Design

Schema: [`configs/rules/rule-schema.json`](../configs/rules/rule-schema.json) (JSON Schema
Draft-07). Rules: [`configs/rules/rules.yaml`](../configs/rules/rules.yaml) — 20 rules, all
validating, distributed exactly as the brief's Day 7 specifies.

## 1. Why configuration and not code

The monolith holds 500+ rules in Java `switch` statements. A threshold change is a release.
During a live attack the response time is six days. Externalising rules to validated
configuration changes the response time to minutes, and that single property is worth more
than any detection improvement in this document.

The cost is that a malformed rule is now a **runtime** risk rather than a compile-time one.
Four controls answer that:

1. **JSON Schema validation on write** — rejected at authoring, never at evaluation.
2. **Compilation to an AST at load**, not interpretation per transaction.
3. **Mandatory simulation** before a rule may be approved.
4. **Atomic ruleset swap** — a version activates whole or not at all.

## 2. Evaluation model

Rules compile to ASTs held in an immutable in-memory `RuleCache`, ordered by `priority`
ascending. Evaluation short-circuits: a `block` action at priority 10 (WAT-001, compromised
card) stops evaluation of the remaining 499 rules, because when the network says the card is
compromised nothing further changes the outcome.

**Temporal windows** are the expensive part. `count over 10m` for a cardholder is a Redis
sorted set keyed `vel:{entity}:{scope}` with the timestamp as score; the query is
`ZCOUNT key now-600000 now` and old members are trimmed on write. Cost is O(log N + M),
p99 under 1 ms. The alternative — a SQL aggregate per rule per transaction — was rejected at
an estimated 8 ms per window, which alone would exceed the rule engine's 15 ms p99 budget.

Rules are evaluated **in parallel within a priority band** and sequentially across bands, so
short-circuit semantics are preserved while independent rules share the wall clock.

## 3. Score composition

Each fired rule contributes a `score_adjust` delta. The engine's output is
`min(1000, sum(deltas))`, capped rather than normalised.

**Why capped and not averaged:** averaging would let a single 900-point compromised-card hit
be diluted by 30 non-firing rules into something below threshold. Fraud signals are evidence,
and evidence accumulates — it does not average out.

**What capping costs:** the score saturates. Once three or four strong rules fire, further
rules add nothing and the score stops discriminating between "bad" and "catastrophic". This
is acceptable because everything above 800 auto-declines anyway, so discrimination above
saturation has no decision consequence. It is flagged here because it would matter if
thresholds ever moved.

## 4. Lifecycle

```mermaid
stateDiagram-v2
    [*] --> DRAFT: analyst authors
    DRAFT --> DRAFT: edit and re-simulate
    DRAFT --> REVIEW: simulation report attached (mandatory)
    REVIEW --> DRAFT: changes requested
    REVIEW --> APPROVED: manager approves
    APPROVED --> ACTIVE: director activates, or shadow period elapses
    ACTIVE --> DEPRECATED: superseded or expiry_date reached
    DEPRECATED --> RETIRED: after 90 day grace
    RETIRED --> [*]
    ACTIVE --> DRAFT: emergency rollback to prior version
    note right of REVIEW
        A rule cannot enter REVIEW without a
        simulation_report_id. This is the single
        control preventing a well-intentioned
        threshold from declining 40,000 genuine
        transactions on a Friday evening.
    end note
```

Segregation of duties: author ≠ approver ≠ activator. Every transition writes to the audit
chain with actor, role and justification.

## 5. Simulation

Backtest against 30 days of replayed enriched transactions, reporting:

| Output | Meaning |
|---|---|
| transactions_evaluated | Replay set size |
| transactions_flagged | Rule hits |
| confirmed_fraud_in_flagged | True positives |
| confirmed_legitimate_in_flagged | False positives |
| detection_rate | TP / all confirmed fraud in window |
| false_positive_rate | FP / all legitimate |
| estimated_annual_fraud_prevented | TP value × 12 |
| estimated_annual_customer_friction | FP count × 12 |
| **label_completeness** | Fraction of the window with mature labels |

**`label_completeness` is the field that keeps simulation honest.** Confirmed-fraud labels
arrive via chargeback 30–90 days after the transaction. A backtest over the *last* 30 days is
therefore scored against a window where most fraud is not yet labelled, and it will
systematically overstate precision and understate detection. The replay window is offset to
**T-120 to T-90 days** so labels are mature, and the report states the completeness figure
explicitly. A simulation run over recent data without this offset produces numbers that look
excellent and mean nothing — this is the most common way rule backtesting misleads, and it is
worth naming rather than quietly handling.

## 6. Shadow mode and A/B

An APPROVED rule runs in shadow for 7 days: evaluated on live traffic, results published to
`fraud.rule.results` with `shadow_mode=true`, never influencing a decision. Comparison is on
trigger rate, overlap with existing rules, and analyst disposition of the transactions it
would have flagged.

Rules whose hits are ≥ 95% subsumed by an existing rule are rejected as redundant. This is how
a rulebook is prevented from reaching 500 entries where nobody knows which ones still matter.

## 7. Per-rule monitoring

Exported per rule: trigger rate, TP rate, FP rate, p99 evaluation micros, last-fired
timestamp. Automated alerts:

| Condition | Severity | Action |
|---|---|---|
| FP rate > 2× 7-day baseline | P2 | Notify rule owner |
| Trigger rate > 5× baseline in 1 h | P2 | Possible attack **or** possible bad rule — both need eyes |
| p99 evaluation > `max_evaluation_time_ms` | P2 | Auto-deprecate candidate |
| Not fired in 90 days | P4 | Retirement review |
| TP rate < 5% over 30 days with > 1,000 triggers | P3 | Rule is generating work, not value |

The last two are the ones that actually keep the rulebook healthy, and the ones most often
omitted.
