# P2 — Decision Latency p99 Above 200 ms

**Severity:** P2 · Slack `#fraud-alerts` · escalates to P1 after 30 minutes or on 14.4× burn

## Symptom
`histogram_quantile(0.99, fraud_decision_latency_bucket) > 0.2` for 5 minutes.

## Attribute the latency before touching anything
Transaction Processing dashboard → per-hop breakdown. The budget
([SLA §4.1](../05_SLA_SPECIFICATION.md)) is:

| Hop | Budget | If exceeded |
|---|---|---|
| Gateway | 5 ms | Gateway CPU, TLS session cache, Redis rate-limit latency |
| Ingestion + enrichment | 35 ms | **Most likely.** Third-party enrichment is the largest single term |
| Rule engine | 15 ms | Ruleset grew, a temporal window is scanning, Redis slow |
| Anomaly detection | 10 ms | Cold model, feature store slow, GPU contention |
| Risk scoring | 8 ms | Rare; check Redis graph-signal read |

## Most common cause: enrichment
```promql
histogram_quantile(0.99, rate(fraud_enrichment_duration_bucket[5m]))
rate(fraud_enrichment_circuit_open_total[5m])
```
At 30 ms of an 84 ms budget, the third-party device-fingerprinting call is the dominant term
and the most likely regression. If the provider has degraded, **open the circuit manually**
rather than waiting for the threshold — transactions proceed with `device_signal=UNAVAILABLE`
and a population default, which is a small accuracy loss against a large latency win:

```bash
kubectl -n fraud set env deploy/transaction-ingestion ENRICHMENT_CIRCUIT_FORCE_OPEN=true
```

## Other causes
- **JVM GC**: `jvm_gc_pause_seconds` p99 above 20 ms. Check heap sizing and allocation rate.
- **Connection pool saturation**: `istio_request_duration` high while service-internal time is
  flat means requests are queueing for connections, not processing slowly. Raise
  `http2MaxRequests` in the DestinationRule.
- **Rule engine growth**: `fraud_rules_evaluated_count` rising. A new rule without effective
  short-circuit priority can add milliseconds across every transaction.
- **HPA lag**: replicas at max while CPU is saturated. Scale manually, then fix the HPA target.

## Do not
Do not raise the SLO. Do not disable the alert. If the breach is accepted as a business
decision, the error-budget policy applies — deploys freeze — and that is the intended
consequence, not a side effect to be worked around.
