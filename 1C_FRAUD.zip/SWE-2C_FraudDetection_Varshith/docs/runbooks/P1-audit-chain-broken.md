# P1 — Audit Hash Chain Verification Failed

**Severity:** P1 · pages immediately, no escalation delay · Compliance and CISO notified in parallel

## Symptom
`fraud_audit_chain_verified == 0`, or `GET /api/v1/audit` returns `chain_verified: false` with
entries in `chain_problems`.

## What it means
An audit entry has been modified, deleted or reordered since it was written. The audit store
is append-only at the database, application and storage layers, so this condition should be
unreachable through any supported path. It is therefore either tampering or a serious defect —
and both are treated as tampering until proven otherwise.

## Immediate actions — in this order

1. **Do NOT restart audit-compliance.** A restart may destroy in-memory state that is
   evidence. This instruction is first because restarting is the reflex.
2. **Freeze audit writes**: scale audit-compliance to 0 replicas. Events continue buffering in
   `fraud.audit.events` (infinite retention) — nothing is lost.
3. **Notify** Head of Compliance and CISO. This is a regulatory notification trigger, not an
   engineering incident.
4. **Snapshot**: PostgreSQL `audit_log` table, the S3 Object Lock mirror, and PostgreSQL WAL
   segments covering the window. Store to a separate account.
5. **Preserve** pod logs, `kubectl describe`, and the Vault audit log for the period.

## Diagnosis

```sql
-- Locate the first broken link
WITH chained AS (
  SELECT event_id, occurred_at, hash, previous_hash,
         LAG(hash) OVER (ORDER BY occurred_at, event_id) AS expected_previous
  FROM audit_log WHERE occurred_at BETWEEN $1 AND $2)
SELECT * FROM chained WHERE previous_hash IS DISTINCT FROM expected_previous LIMIT 10;
```

Then compare PostgreSQL against the S3 Object Lock mirror. S3 in compliance mode cannot be
altered even by the account root, so **the mirror is authoritative**. Divergence between the
two localises the tampering to the database layer.

| Finding | Interpretation |
|---|---|
| PG and S3 agree, both break at entry N | Corruption or a defect at write time |
| PG broken, S3 intact | Database tampering. Security incident |
| PG intact, S3 broken | Impossible under compliance mode — investigate the mirroring job |
| Gap in `event_id` sequence | Deletion. This is the case the chain exists to catch |

## Remediation
- **Defect**: fix, rebuild the chain by replaying `fraud.audit.events` from Kafka into a new
  table, verify, swap. Never edit the existing chain — an edited audit trail is not an audit
  trail.
- **Tampering**: hand to the security incident process. Do not remediate; preserve.

## Recovery
Restore writes only after the chain verifies clean from genesis and Compliance has signed off
in writing. Expect to replay the Kafka backlog.

## Prevention check after any occurrence
Confirm the DB role still has `INSERT` only; confirm the `UPDATE`/`DELETE` trigger is present;
confirm S3 Object Lock retention is unexpired; confirm dual authorisation is enforced in Vault.
