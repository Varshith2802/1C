# P1 — Detection Rate Below 80%

**Severity:** P1 · pages · escalates to Head of Fraud Ops after 5 minutes

## Symptom
`fraud_detection_rate_7d < 0.80` sustained 15 minutes. SLO is 95%; retraining triggers at 90%.
Reaching 80% means two thresholds were already passed.

## First, establish whether this is real

Detection rate is computed against **mature labels** (T-120 to T-90 days). A sudden move in a
7-day figure is more often a measurement artefact than a detection failure.

```promql
fraud_label_completeness_ratio        # if this dropped, the metric is broken, not detection
rate(fraud_cases_dispositioned_total[1d])   # analysts not dispositioning starves the label feed
```

If label completeness fell, this is a **data pipeline incident**, not a detection incident.
Route accordingly and stop here. Chasing a detection failure that is actually a broken metric
burns hours.

## If detection genuinely dropped — differential

| Check | Command / query | Implication |
|---|---|---|
| Ruleset version changed? | `fraud_active_ruleset_version` | A bad rule activation. **Roll back first, diagnose after** |
| Model version changed? | `fraud_active_model_version` | Bad model promotion. Roll back to champion |
| Engine degraded? | `fraud_engine_available{engine=~"RULE\|ML\|GRAPH"}` | Silent degradation; scores computed on partial evidence |
| Feature defaults high? | `rate(fraud_feature_store_defaults_total[1h])` | Feature store degraded — model near-blind |
| Drift? | `max(fraud_model_psi)` | Gradual, not sudden. Unlikely to be the cause of a step change |
| Score distribution shifted? | Fraud Detection dashboard histogram | Shift left = engines under-scoring |
| Attack pattern changed? | New MCC/geo/channel concentration in confirmed fraud | **Concept drift** — see below |

## The case the differential will not find

If every engine is healthy, no version changed, features are fine and PSI is near zero, but
detection has still collapsed — this is **concept drift with an adaptive adversary**. The
inputs look statistically normal because the attacker has learned what normal looks like.

This is the hardest case and no dashboard will name it. Indicators: confirmed fraud clustering
in a pattern no rule covers; ML scores sitting just below threshold with suspicious
consistency; graph showing new ring structures.

Response is human, not automated: convene fraud ops and data science, examine confirmed-fraud
cases from the last 30 days by hand, author emergency rules against the observed pattern,
trigger off-cycle retraining, and consider lowering thresholds temporarily — accepting a
higher false positive rate is the correct trade when detection has collapsed.

## Rollback commands
```bash
kubectl -n fraud exec deploy/rule-engine -- \
  grpcurl -d '{"target_version":"<previous>","requested_by":"<oncall>"}' \
  localhost:9090 shieldpay.fraud.v1.RuleEngineService/ReloadRuleset

kubectl -n fraud set image deploy/anomaly-detection \
  anomaly-detection=registry/anomaly-detection:<previous-tag>
```

## Do not
Do not raise thresholds to make the alert stop. The alert measures reality; suppressing it
leaves fraud undetected and removes the only signal that it is happening.
