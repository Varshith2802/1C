# Security, Encryption and Regulatory Compliance

Istio configuration: [`configs/istio/mesh-policies.yaml`](../configs/istio/mesh-policies.yaml).

## 1. Service communication matrix

Default is **deny**. Every cell marked ✅ is an explicit `AuthorizationPolicy` grant.

| From ↓ / To → | ingest | rules | ml | graph | risk | case | notify | audit | analytics |
|---|---|---|---|---|---|---|---|---|---|
| **api-gateway** | ✅ | ✅ read | — | — | — | ✅ | — | ✅ GET | ✅ |
| **transaction-ingestion** | — | ✅ | ✅ | — | ✅ | — | — | — | — |
| **rule-engine** | — | — | — | — | — | — | — | — | — |
| **anomaly-detection** | — | — | — | — | — | — | — | — | — |
| **graph-analysis** | — | — | — | — | — | — | — | — | — |
| **risk-scoring** | — | — | — | — | — | — | — | — | — |
| **case-management** | — | — | — | ✅ FindRing | ✅ GetDecision | — | — | — | — |
| **notification** | — | — | — | — | — | — | — | — | — |
| **saga-orchestrator** | — | — | — | — | — | ✅ | ✅ | — | — |

Three properties are worth reading off this table:

- **The detection engines make no outbound calls to each other.** Rule, ML and graph never
  talk. Their independence is the whole point of defence in depth — an engine that consults
  another engine correlates their failures.
- **notification has no outbound row at all.** It is a leaf. The brief's own least-privilege
  example ("Notification should not be able to call the Rule Engine") is enforced structurally
  rather than by policy text.
- **audit accepts only GET, from the gateway.** No platform service, and no human role
  including ADMIN, has a write path.

## 2. Encryption

| Layer | Control |
|---|---|
| In transit, external | TLS 1.3 only, terminated at the gateway. TLS 1.2 and below disabled |
| In transit, internal | mTLS STRICT via Istio. `PERMISSIVE` is not used anywhere, including during migration |
| At rest, PostgreSQL | AES-256, `pgcrypto` for column-level on sensitive fields; volume encryption beneath |
| At rest, Kafka | Broker-level disk encryption; `fraud.audit.events` additionally application-encrypted |
| At rest, Redis | Encrypted volumes; feature store holds no PII, only derived numerics |
| At rest, Neo4j | Encrypted volumes; graph holds hashed identifiers only |
| At rest, S3 | SSE-KMS with Object Lock in compliance mode for the audit archive |
| Key management | HashiCorp Vault; 90-day rotation for data keys, annual for the HMAC card-hash key |

**The card-hash key rotation problem, stated because it is easy to miss.** `card_number_hash`
is an HMAC used as a join key across Kafka, PostgreSQL, Redis and Neo4j. Rotating that key
invalidates every stored hash simultaneously. The design uses **versioned key derivation**:
each hash is prefixed with a key generation (`v3:9f2a…`), both generations are accepted
during an overlap window, and a background job re-derives historical hashes. Without this,
"annual key rotation" is a policy that can never actually be executed, which is worse than
having no policy because it looks compliant on paper.

## 3. PCI DSS v4.0 requirement mapping

| Req | Requirement | Component that satisfies it | Evidence |
|---|---|---|---|
| 1 | Network security controls | Kubernetes `NetworkPolicy` + Istio `AuthorizationPolicy` | [mesh-policies.yaml](../configs/istio/mesh-policies.yaml), [k8s manifests](../samples/k8s/) |
| 2 | Secure configurations | Distroless images, no default credentials, Vault-sourced secrets | [Dockerfiles](../samples/docker/) |
| 3 | **Protect stored account data** | PAN never persisted. Tokenised at ingestion; only `card_number_hash` + `pan_last_four` exist downstream. The `TransactionEvent` schema has no PAN field | [events.proto](../api-specs/events.proto) |
| 4 | Encrypt transmission over public networks | TLS 1.3 at edge, mTLS internal | Istio `PeerAuthentication: STRICT` |
| 5 | Protect against malware | Trivy image scanning in CI, blocking on HIGH/CRITICAL | [CI/CD](15_CICD_AND_DR.md) |
| 6 | Secure development | SAST, dependency scanning, mandatory PR review, signed images | [CI/CD](15_CICD_AND_DR.md) |
| 7 | Restrict access by need to know | RBAC at gateway, per-service `AuthorizationPolicy` | §1 matrix |
| 8 | Identify and authenticate users | RS256 JWT, MFA for analyst and admin consoles, per-service SPIFFE identity | Gateway config |
| 9 | Restrict physical access | Cloud provider responsibility; shared-responsibility matrix documented | — |
| 10 | **Log and monitor all access** | Hash-chained audit trail; every cardholder-data access logged with actor, role and justification | §4 |
| 11 | Test security regularly | Quarterly pentest, continuous scanning, chaos experiments | [CI/CD](15_CICD_AND_DR.md) |
| 12 | Information security policy | Organisational; out of architectural scope and named as such | — |

**Requirement 3 is satisfied by schema design, not by process.** The PAN field does not exist
in any event, API or database schema past the tokenisation component. A control that depends
on developers remembering not to log something will fail eventually; a control that depends on
the field being absent cannot.

## 4. Audit trail

Design carried directly from the Wirecard lesson (C4): the fraud persisted for years because
reconciliation reports were manually produced artefacts, not system output.

| Property | Implementation |
|---|---|
| Append-only | PostgreSQL trigger rejecting `UPDATE`/`DELETE`; role has `INSERT` only |
| Tamper-evident | SHA-256 over the entry, chained to `previous_hash` |
| Deletion-evident | The chain link is what detects removal. A per-entry hash alone detects modification but not deletion — and Wirecard was a deletion-and-fabrication problem |
| Storage-level immutability | Mirrored to S3 Object Lock (compliance mode) — not even the account root can delete within the retention period |
| Independently verifiable | `GET /api/v1/audit` recomputes the chain over the returned range and returns `chain_verified`, so a regulator need not trust the application's own claim |
| Dual authorisation | Any maintenance operation on the audit store requires two named approvers; enforced by Vault policy, not by convention |

Logged: every fraud decision with complete inputs and all engine signals, every rule change,
every model deployment, every threshold modification, every cardholder-data access, every
configuration change.

## 5. RBI compliance

| Requirement | Implementation |
|---|---|
| Real-time fraud monitoring | Inline per-transaction scoring; the 15-minute batch window is eliminated |
| Additional Factor of Authentication | `step_up_auth` action with OTP, biometric, challenge-question methods |
| Fraud reporting above threshold | Automated report generation from the decision store, filed via SFTP |
| STR filing to FIU-IND | Case disposition `CONFIRMED_FRAUD` above threshold generates a draft STR for compliance review — **drafted, not auto-filed**: an STR is a legal assertion and requires a human signatory |
| Record retention | 7 years, tiered hot/warm/cold |
| Tokenisation | Card-on-file tokens only; raw PAN never at rest |

## 6. GDPR versus RBI

The conflict and its resolution are in
[Persistence Strategy §3](06_PERSISTENCE_STRATEGY.md#3-retention-and-the-gdprrbi-conflict).
In summary: jurisdiction-scoped pseudonymisation rather than deletion, with the identifier
mapping in a separate vault whose key is destroyed at end of retention. The financial record
and the audit chain survive intact; re-identification becomes cryptographically infeasible.

The residual case — an EU-issued card transacting in India, under both regimes at once — is a
legal determination, not an architectural one. The architecture's contribution is keeping
identity separable from the financial record from day one, so that either legal answer is
implementable. Flagged to Legal in the Board deck rather than resolved here.

## 7. Threat model: what this architecture does not stop

Stated explicitly, because a compliance mapping with no residual-risk section is a marketing
document.

| Threat | Coverage | Residual risk |
|---|---|---|
| Stolen card, CNP | Rules + ML + graph | Low |
| Enumeration | VEL-004 + gateway rate limiting | Low |
| Synthetic identity ring | Graph (T2 template) | **Medium** — defeated by per-identity infrastructure discipline |
| Account takeover | Device and behavioural signals | Medium — a patient attacker mimicking the victim's pattern is very hard |
| Friendly fraud | None at authorisation | **High, and irreducible.** The transaction is genuine; no real-time control can distinguish it. Handled post-hoc via chargeback defence |
| Insider (analyst) | Audit trail, RBAC, dual authorisation | Medium — detective, not preventive |
| Insider (platform engineer) | Vault, signed images, mandatory review | **Medium** — an engineer with deploy rights can alter detection logic. The audit chain records it; it does not prevent it |
| Model evasion | Isolation forest, graph, rules | **Medium** — an adversary with query access can probe decision boundaries. Rate limiting raises the cost, it does not remove the attack |
| POS malware (Target) | Out of scope | **High** — reconciliation verifies financial accuracy, not data security. Belongs to endpoint security, and this platform should not be presented as covering it |
| Switch bypass (Cosmos) | GEO-001 + core-banking integrity verification | Medium — depends on the CBS cross-check being genuinely independent of the compromised path |
