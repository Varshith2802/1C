# Risk & Technology Board — Platform Re-Architecture
### 15 minutes · Platform Architect · Project 463549C

---

## Slide 1 — The problem is the batch window (90s)

Losses ₹12cr → ₹53cr per quarter. False positives 0.3% → 2.1%.

**Both directions got worse at once.** That is not a tuning failure — a tuned system trades
one against the other. It is an architecture that has stopped fitting the problem.

Root cause: **15-minute batch scoring**. Fraudsters reverse-engineered the cron schedule and
timed transactions to land just after a run. 10–20 transactions each, entirely unscored.
Batch scoring cannot inform an authorisation decision; by the time it produces a number the
money has moved.

Everything that follows is secondary to closing that window.

---

## Slide 2 — Target architecture (90s)

Nine services · three independent detection engines · event-driven backbone · p99 200 ms.

| Engine | Detects | Needs labels? |
|---|---|---|
| Rules | Known patterns, policy, regulatory | No |
| ML | Statistical deviation at volume | Yes — 30–90 day lag |
| Graph | Rings via shared infrastructure | No |

Nine, not twelve. Each extra service on the critical path costs ~2 ms, one failure mode and
one more 3 a.m. page. The brief's range tops out at twelve; that is not a reason to reach it.

---

## Slide 3 — The finding that changed the design (2 min)

The brief asks us to choose between synchronous and asynchronous graph updates. **The
arithmetic removes the choice.**

| | p99 |
|---|---|
| Synchronous path today | 84 ms |
| Plus synchronous graph (+2 hop, +50 query) | **136 ms** |
| gRPC critical-path budget (§A1.4) | 100 ms |
| Pipeline SLO (§A3.3) | 200 ms |

136 ms breaches the gRPC budget outright and leaves 64 ms to absorb GC pauses, pool waits and
a Neo4j leader re-election. It will not hold.

**Graph runs asynchronously.** 1–5 s staleness, disclosed in the decision contract, with a
conservative risk margin when the signal is missing — because reading "no signal" as "no risk"
is what makes staleness dangerous. The single-hop case is covered synchronously by a rule.

*We also found the brief's own decision SLA (§A2.5, <100 ms) is tighter than the pipeline that
produces it (§A3.3, 200 ms) and carries no percentile.*

---

## Slide 4 — CRO: detection and explainability (2 min)

**The label-lag constraint, stated plainly.** Confirmed fraud arrives by chargeback 30–90 days
later. A supervised model cannot detect a novel attack while it is running. The synthetic
ring aged accounts 90 days and busted out in one — no retraining cadence produces labels that
do not yet exist.

**So ML carries volume. Rules and graph carry novelty.** Both work without labels. Making ML
the primary defence against emerging fraud would repeat the monolith's mistake in more
fashionable clothing.

Every decision returns: rules fired with matched values · top five SHAP contributions · graph
paths · each engine's weighted share. Assembled for a regulator, not for a log.

**What we do not claim:** a detection rate. The platform has processed no transactions. The
first real measurement comes from shadow mode in migration phase 2, before any decision risk
is taken.

---

## Slide 5 — CTO: resilience (2 min)

Every service has a defined degraded mode. Two worth the Board's attention:

- **Rule engine down** → fail closed above ₹50,000, open below. Uniform fail-closed declines
  28 TPS of legitimate traffic and creates a customer-service incident in minutes. Uniform
  fail-open leaves everything unscreened. The split bounds loss while keeping the ordinary
  majority flowing. The threshold is yours to set, not engineering's.
- **Audit down does NOT stop decisions.** Deliberate. Audit events reach Kafka with infinite
  retention before the service consumes them, so the durable record exists regardless. Making
  a compliance control into an availability dependency guarantees someone adds a bypass during
  the first outage — which is far worse.

Seven chaos experiments defined. Experiment 4 (Kafka leader kill) is the one most likely to
fail first time; zero message loss needs four settings correct simultaneously.

---

## Slide 6 — Compliance (2 min)

- **PCI DSS Req 3 by schema, not by policy.** No PAN field exists past tokenisation. A control
  that depends on developers remembering will fail; a field that does not exist cannot leak.
- **Audit chained, not just hashed.** The chain link detects *deletion*. Wirecard was
  deletion-and-fabrication, not modification.
- **Key rotation actually executable.** `card_number_hash` is a join key across four stores;
  rotating it naively invalidates every stored hash at once. Versioned derivation with an
  overlap window makes the annual rotation something that can happen rather than something
  written down.
- **GDPR vs RBI:** jurisdiction-scoped pseudonymisation, not deletion. The dual-jurisdiction
  cardholder is a **legal** determination — flagged to Legal, not resolved by engineering.
- **Data residency:** Indian data replicates in-country, not to Singapore. The obvious DR
  topology would be a regulatory breach.

---

## Slide 7 — VP Engineering: operability (90s)

Nine services map to teams of 3–5. Deployment differentiated: canary for ML, blue-green for
rules (a partial ruleset is worse than the old one), rolling with `maxUnavailable: 0` for
ingestion.

Migration phases 1–3 carry **zero decision risk** by construction — the monolith still decides
while the new path is proven against it in shadow. Credibility is spent at phase 4, where it
is needed.

**Named dependency, not an assumption:** ShieldPay has no in-house Neo4j cluster operations
capability. Hire or buy managed. This is on the critical path.

---

## Slide 8 — CFO (2 min)

| | Monthly |
|---|---|
| New platform | ~$176,000 |
| Legacy | ~$95,000 |
| **Delta** | **+$81,000 (~$1 M/year)** |

$0.0024 per transaction, falling to $0.0016 at 5 M/day.

**This costs about $1 M/year more to run.** It is justified only if it recovers a meaningful
share of the ₹41 crore/quarter increase in losses. 15% recovery pays for it four times over.

Two caveats I will not bury: the detection improvement is a **projection**, and these figures
come from list prices against declared resource requests — not a quote, not a bill.

---

## Slide 9 — Risks we are accepting (90s)

| Risk | Position |
|---|---|
| Friendly fraud | **Irreducible.** The transaction is genuine. No authorisation control catches it. Excluded from targets |
| Disciplined ring tradecraft | Per-identity infrastructure leaves no graph edges. Ceiling set by the adversary |
| POS malware (Target class) | **Out of scope.** We verify financial accuracy, not data security. Do not let this platform be presented as covering it |
| Insider with deploy rights | Audit records it. It does not prevent it |
| Cross-region RPO 10–30 s | Physics. Bounded, reconstructable from Kafka |

---

## Slide 10 — Ask (60s)

1. Approve the nine-service decomposition and the asynchronous graph decision.
2. Approve the phased migration with shadow-mode gates at phases 2–3.
3. **Set the fail-closed value threshold** (₹50,000 proposed) — a business decision.
4. Approve Neo4j operations hiring or managed service.
5. Refer the dual-jurisdiction GDPR/RBI question to Legal.
6. Confirm the RBI retention period: this brief says 7 years, a sibling Zetheta brief says 10.

**Questions.**
